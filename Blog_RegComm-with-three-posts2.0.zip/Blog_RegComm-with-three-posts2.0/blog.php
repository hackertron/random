<?php 
$installed = '';
if(!isset($configs_are_set_blog)) {
	include( dirname(__FILE__). "/configs.php");
}

$SysMessage = "";

if(isset($_REQUEST["act"])) {
  	if ($_REQUEST["act"]=='logout') {	
		//setcookie("CommEnTsUsErLOGiN", "", 0);
		//$_COOKIE["CommEnTsUsErLOGiN"] = "";
		//setcookie("UserId", "", 0);
		//$_COOKIE["UserId"] = "";
		
		$_SESSION["CommEnTsUsErLOGiN"] = "";
		unset($_SESSION["CommEnTsUsErLOGiN"]);
		$_SESSION["UserId"] = "";
		unset($_SESSION["UserId"]);
		
 	} elseif ($_REQUEST["act"]=='login') {
 		$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE useremail='".SafetyDB($_REQUEST["useremail"])."' AND password='".SafetyDB(($_REQUEST["password"]))."' AND status='active'";
		$sql_result = sql_result($sql);
	
  	if (mysqli_num_rows($sql_result)==1) {
		$UserId = mysqli_fetch_assoc($sql_result);
		//setcookie("CommEnTsUsErLOGiN", "LoggedIn", time()+24*3600, "/");
		//$_COOKIE["CommEnTsUsErLOGiN"] = "LoggedIn";
		//setcookie("UserId", $UserId["id"], time()+24*3600, "/");
		//$_COOKIE["UserId"] = $UserId["id"];
		
		$_SESSION["CommEnTsUsErLOGiN"] = "LoggedIn";	
		$_SESSION["UserId"] = $UserId['id'];
		
		unset($_REQUEST['act']);		
		//$_REQUEST['act']=$_REQUEST['act2'];
		
		//$_REQUEST['pid']=$_REQUEST['pidr'];
		
  	} else {
		$SysMessage = 'Incorrect login details or inactive registration! ';
		//$_REQUEST["act"] = 'loginform';
  	}
  }
}

$Logged = false;
//if ((isset($_COOKIE["CommEnTsUsErLOGiN"])) and ($_COOKIE["CommEnTsUsErLOGiN"]=="LoggedIn")) {
if ((isset($_SESSION["CommEnTsUsErLOGiN"])) and ($_SESSION["CommEnTsUsErLOGiN"]=="LoggedIn")) {
	$Logged = true;
	$UserId = $_SESSION['UserId'];
}

$thisPage = $_SERVER['PHP_SELF'];
if(!isset($_REQUEST["search"])) $_REQUEST["search"] = ''; 
if(!isset($_REQUEST["p"])) { 
	$_REQUEST["p"] = ''; 
} elseif(isset($_REQUEST["p"]) and $_REQUEST["p"]!="") {
	$_REQUEST["p"]= (int) urlencode($_REQUEST["p"]);
}

$search='';
if(isset($_REQUEST["search"]) and ($_REQUEST["search"]!="")) {
	$find = SafetyDB(urldecode($_REQUEST["search"]));
	$search .= " AND (post_title LIKE '%".$find."%' OR post_text LIKE '%".$find."%')";
}  

if(isset($_REQUEST["cat_id"]) and $_REQUEST["cat_id"]!='') { 
	$_REQUEST["cat_id"] = (int) SafetyDB($_REQUEST["cat_id"]);
} else {
	$_REQUEST["cat_id"] = ''; 
}
if ($_REQUEST["cat_id"]>0) $search .= " AND `cat_id`= ".SafetyDB(htmlentities($_REQUEST["cat_id"]));

$error='';

/* define ReCaptcha */
$publickey = "6Lfk9L0SAAAAACp13Wlzz6WTanYxrcLBXyn7XNSJ";
$privatekey = "6Lfk9L0SAAAAAMccSmLp8kxaMQ53yJyVE0kuOSrh";

# the response from reCAPTCHA
$resp = null;
# the error code from reCAPTCHA, if any
$error = null;
/* define ReCaptcha end */

$sql = "SELECT * FROM ".$TABLE["Options"];
$sql_result = sql_result($sql);
$Options = mysqli_fetch_assoc($sql_result);
mysqli_free_result($sql_result);
$Options["comm_req"] = unserialize($Options["comm_req"]);
$OptionsVis = unserialize($Options['visual']);
$OptionsVisC = unserialize($Options['visual_comm']);
$OptionsLang = unserialize($Options['language']);

if(trim($Options['time_zone'])!='') {
	date_default_timezone_set(trim($Options['time_zone']));
}
$cur_date = date('Y-m-d H:i:s');

if(!function_exists('lang_date')){ 
	function lang_date($subject) {	
		$search  = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
		
		$replace = array(
						ReadDB($GLOBALS['OptionsLang']['January']), 
						ReadDB($GLOBALS['OptionsLang']['February']), 
						ReadDB($GLOBALS['OptionsLang']['March']), 
						ReadDB($GLOBALS['OptionsLang']['April']), 
						ReadDB($GLOBALS['OptionsLang']['May']), 
						ReadDB($GLOBALS['OptionsLang']['June']), 
						ReadDB($GLOBALS['OptionsLang']['July']), 
						ReadDB($GLOBALS['OptionsLang']['August']), 
						ReadDB($GLOBALS['OptionsLang']['September']), 
						ReadDB($GLOBALS['OptionsLang']['October']), 
						ReadDB($GLOBALS['OptionsLang']['November']), 
						ReadDB($GLOBALS['OptionsLang']['December']), 
						ReadDB($GLOBALS['OptionsLang']['Monday']), 
						ReadDB($GLOBALS['OptionsLang']['Tuesday']), 
						ReadDB($GLOBALS['OptionsLang']['Wednesday']), 
						ReadDB($GLOBALS['OptionsLang']['Thursday']), 
						ReadDB($GLOBALS['OptionsLang']['Friday']), 
						ReadDB($GLOBALS['OptionsLang']['Saturday']), 
						ReadDB($GLOBALS['OptionsLang']['Sunday'])
						);
	
		$lang_date = str_replace($search, $replace, $subject);
		return $lang_date;
	}
}


/////////////////////////////////////////////////
////// checking for correct captcha and text confirmation starts //////
if (isset($_POST["act"]) and $_POST["act"]=='addUser') {
	
	if($Options['captcha']=='nocap') { // if the option is set to no Captcha
		$testvariable = true;	// test variable is set to true
	} else {
		$testvariable = false;	// test variable is set to false
	}
		
	if($Options['captcha']=='recap') { // if the option is set to reCaptcha
	
		$privatekey = "6Lfk9L0SAAAAAMccSmLp8kxaMQ53yJyVE0kuOSrh";
		if ($_POST["recaptcha_response_field"]) {
			$resp = recaptcha_check_answer ($privatekey, $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"]);
	
			if ($resp->is_valid) { // test variable is set to true				
					$testvariable = true;				
				} else {
				# set the error code so that we can display it
				$error = $resp->error;
				$SysMessage =  ReadDB($OptionsLang["Incorrect_verification_code"]); 
				$_REQUEST["act"] = 'register';
			}
		} else {		
			$SysMessage = ReadDB($OptionsLang["Incorrect_verification_code"]); 
			$_REQUEST["act"] = 'register';
		}		
		
	} elseif($Options['captcha']!='recap' and $Options['captcha']!='nocap') { // if is set to math or simple or very simple captcha option	
		if (preg_match('/^'.$_SESSION['key'].'$/i', $_REQUEST['string'])) { // test variable is set		
				$testvariable = true;			
			} else {		
			$SysMessage = ReadDB($OptionsLang["Incorrect_verification_code"]); 
			$_REQUEST["act"] = 'register';
		}
	}	
	
}
////// checking for correct captcha and text confirmation ends //////
/////////////////////////////////////////////////////////////////////


// user registration
if(isset($_REQUEST["act"]) and $_REQUEST["act"] == "addUser"){
	
	if ($testvariable==true) { // if test variable is set to true, then go to update database and send emails
	
		$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE useremail='".$_REQUEST["useremail"]."'";
		$sql_result = sql_result($sql);
		if(mysqli_num_rows($sql_result)>0) 
		{	
			$SysMessage = ReadDB($OptionsLang["user_exist"]); 
			$_REQUEST["act"] = "register";
		}	
		elseif(trim($_REQUEST["useremail"])=="") {
			$SysMessage = ReadDB($OptionsLang["correct_email"]);
			$_REQUEST["act"] = "register";
		}
		elseif( preg_match("/[.+a-zA-Z0-9_-]+@[a-zA-Z0-9-_]+/i", $_REQUEST["useremail"]) == 0 ) {
			$SysMessage = ReadDB($OptionsLang["correct_email"]);
			$_REQUEST["act"] = "register";
		}
		//elseif( preg_match("/[.+a-zA-Z0-9_-]+@[a-zA-Z0-9-_]+\.[a-zA-Z]+/", $_REQUEST["useremail"]) == 0 ) {
		//	$SysMessage = 'Please enter correct login email!';
		//}
		elseif(trim($_REQUEST["password"])=="" or strlen(trim($_REQUEST["password"]))<3){
			$SysMessage = ReadDB($OptionsLang["pass_min_3_char"]);
			$_REQUEST["act"] = "register";
		}
		elseif(trim($_REQUEST["username"])=="") {
			$SysMessage = 'Please enter your name!';
			$_REQUEST["act"] = "register";
		} 
		else {
			$sql = "INSERT INTO ".$TABLE["Users"]." 
					SET status = 'active', 
						username = '".SaveDB($_REQUEST["username"])."', 
						useremail = '".SaveDB($_REQUEST["useremail"])."', 
						password = '".($_REQUEST["password"])."'";
			$sql_result = sql_result($sql);
			
			$index_id = mysqli_insert_id($connBl);
			
			$user_id = $index_id;
	
			if (isset($_FILES["image"]) and is_uploaded_file($_FILES["image"]['tmp_name'])) {
				
				$filexpl = explode(".", $_FILES["image"]['name']);
				$format = end($filexpl);					
				$formats = array("jpg","jpeg","JPG","png","PNG","gif","GIF");				
				if(in_array($format, $formats) and getimagesize($_FILES['image']['tmp_name'])) {	
					
					$name = $_FILES['image']['name'];
					$name = str_replace(array(" ", "%20"), "_", $name); 
					$name = $index_id . "_" . $name;
					
					$filePath = $CONFIG["server_path"].$CONFIG["upload_folder"] . $name;
					
					if (move_uploaded_file($_FILES["image"]['tmp_name'], $filePath)) {
						chmod($filePath, 0777);
						Resize_File($filePath, $OptionsVisC["avat_width"], 0); 
	
						$sql = "UPDATE ".$TABLE["Users"]."  
								SET image = '".$name."'  
								WHERE id='".$index_id."'";
						$sql_result = sql_result($sql);
						$SysMessage = '';
					} else {
						$SysMessage .= 'Cannot copy uploaded file to "'.$filePath.'". Try to set the right permissions (CHMOD 777) to "'.$CONFIG["upload_folder"].'" directory.'; 
					}
				} else {
					$SysMessage .= ReadDB($OptionsLang["Avatar_must_be_image"]);  
				}
			} else { $SysMessage = ReadDB($OptionsLang["Avatar_not_uploaded"]); }	
			
				
			// email to admin for new registration		
			$mailheader = "From: ".$Options["email"]."\r\n";
			$mailheader .= "Reply-To: ".$Options["email"]."\r\n";
			$mailheader .= "Content-type: text/html; charset=utf-8\r\n";
			$msg_body = ReadDB($OptionsLang["Login_Email"])." " . $_REQUEST["useremail"] . "<br>\n" .
						ReadDB($OptionsLang["Login_Password"])." " . $_REQUEST["password"] . "<br>\n" .
						ReadDB($OptionsLang["Screen_Name"])." " . $_REQUEST["username"] . "<br><br>\n";	
			
			
			//$msg_body .= "Please click on the link below to confirm your registration. <br>\n";
			//$msg_body .= "<a href='".$CONFIG["full_url"]."status.php?u=".$user_id."&h=".($user_id.' _ '.mysql_escape_string($_REQUEST["username"]." _ ".$_REQUEST["useremail"]))."'>".$CONFIG["full_url"]."status.php?u=".$user_id."&h=".($user_id.' _ '.mysql_escape_string($_REQUEST["username"]." _ ".$_REQUEST["useremail"]))."</a> <br /><br />\n";
			
			//$msg_body .= "If the link is not active, please copy and paste it in your browser. <br>\n";
			
			// email to registered user
			mail($_REQUEST["useremail"], ReadDB($OptionsLang["Subject_user_successful_registration"]), $msg_body, $mailheader);
			
			$msg_body .= ReadDB($OptionsLang["Click_on_the_link_below"]).' <br />   
			<a href="'.$CONFIG["full_url"].'admin.php">'.$CONFIG["full_url"].'admin.php'.'</a><br /><br />';
			// email to admin
			mail($Options["email"], ReadDB($OptionsLang["Subject_admin_successful_registration"]), $msg_body, $mailheader);
					
			
			$SysMessage = ReadDB($OptionsLang["Thank_you_for_registration"]);
		}
	} else {		
		$SysMessage =  ReadDB($OptionsLang["Incorrect_verification_code"]); 
		$_REQUEST["act"] = "register";
	}
	
} elseif(isset($_REQUEST["act"]) and $_REQUEST["act"] == "sendPass"){
	
	$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE useremail = '".SafetyDB($_REQUEST["useremail"])."'";
	$sql_result = sql_result($sql);
	if(mysqli_num_rows($sql_result)>0) {
		$UserArr = mysqli_fetch_assoc($sql_result);
	
		// email to user for password		
		$mailheader = "From: ".$Options["email"]."\r\n";
		$mailheader .= "Reply-To: ".$Options["email"]."\r\n";
		$mailheader .= "Content-type: text/html; charset=utf-8\r\n";
		$msg_body = ReadDB($OptionsLang["Password_sent_to_email"])." " . stripslashes($UserArr["password"]) . "<br><br>\n";
		
		// email to user
		mail($_REQUEST["useremail"], ReadDB($OptionsLang["Your_login_password"]), $msg_body, $mailheader);
		$SysMessage = ReadDB($OptionsLang["Password_sent_provided_email"]);  
		$_REQUEST["act"]="loginform";
	} else {
		$SysMessage = ReadDB($OptionsLang["We_dont_have_user"]);   
		$_REQUEST["act"]="forgot";
	}
	

} elseif(isset($_REQUEST["act"]) and $_REQUEST["act"] == "updateAvatar"){
	
	$sql = "SELECT * FROM ".$TABLE["Options"];
	$sql_result = sql_result($sql);
	$Options = mysqli_fetch_assoc($sql_result);
	$OptionsVis = unserialize($Options['visual']);
	
	$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE id = '".$UserId."'";
	$sql_result = sql_result($sql);
	$imageArr = mysqli_fetch_assoc($sql_result);
	$image = stripslashes($imageArr["image"]);
	
	$index_id = $UserId;
		
	if (is_uploaded_file($_FILES["image"]['tmp_name'])) { 
	
		$filexpl = explode(".", $_FILES["image"]['name']);
	  	$format = end($filexpl);			
	  	$formats = array("jpg","jpeg","JPG","png","PNG","gif","GIF");
	  	if(in_array($format, $formats) and getimagesize($_FILES['image']['tmp_name'])) {
		
			if($image != "") unlink($CONFIG["server_path"].$CONFIG["upload_folder"].$image);
			
			$name = $_FILES['image']['name'];
			$name = str_replace(array(" ", "%20"), "_", $name); 
			$name = $index_id . "_" . $name;
			
			$filePath = $CONFIG["server_path"].$CONFIG["upload_folder"] . $name;
			
			if (move_uploaded_file($_FILES["image"]['tmp_name'], $filePath)) {
				chmod($filePath,0777); 				
				Resize_File($filePath, $OptionsVisC["avat_width"], 0); 
				
				$sql = "UPDATE `".$TABLE["Users"]."` 
						SET `image` = '".SafetyDB($name) ."' 
						WHERE id = '".$index_id."'";
				$sql_result = sql_result($sql);
			} else {
				$SysMessage = 'Cannot copy uploaded file to "'.$filePath.'". Try to set the right permissions (CHMOD 777) to "'.$CONFIG["upload_folder"].'" directory.'; 
			}
		} else {
		  	$SysMessage .= ReadDB($OptionsLang["Avatar_must_be_image"]);  
	  	}
	}		
	//$_REQUEST["act"] = "users";		
	$SysMessage .= ReadDB($OptionsLang["Avatar_updated"]);  
	$_REQUEST["act"] = "editProfile";
	
	
} elseif (isset($_REQUEST["act2"]) and $_REQUEST["act2"]=="delImage") { 
	
	$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE id = '".$UserId."'";
	$sql_result = sql_result($sql);
	$imageArr = mysqli_fetch_assoc($sql_result);
	$image = stripslashes($imageArr["image"]);
	if($image != "") unlink($CONFIG["server_path"].$CONFIG["upload_folder"].$image);
	
	$sql = "UPDATE `".$TABLE["Users"]."` SET `image` = '' WHERE id = '".$UserId."'";
	$sql_result = sql_result($sql);
	
	$SysMessage = ReadDB($OptionsLang["Avatar_deleted"]);  
	$_REQUEST["act"] = "editProfile";
	
	
} elseif(isset($_REQUEST["act"]) and $_REQUEST["act"] == "updatePass"){
	
	$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE id='".$UserId."' AND password='".($_REQUEST["oldpassword"])."'";
	$sql_result = sql_result($sql);
	$User = mysqli_fetch_assoc($sql_result);
	if(mysqli_num_rows($sql_result)!=1) 
	{	
		$SysMessage = ReadDB($OptionsLang["Wrong_old_password"]);
		$_REQUEST["act2"] = "changePass";
		$_REQUEST["act"] = "editProfile";
	}	
	elseif(trim($_REQUEST["newpassword"])=="" or strlen(trim($_REQUEST["newpassword"]))<3){
		$SysMessage = ReadDB($OptionsLang["pass_min_3_char"]);  
		$_REQUEST["act2"] = "changePass";
		$_REQUEST["act"] = "editProfile";
	}
	elseif(trim($_REQUEST["newpassword"]) != trim($_REQUEST["newpassword2"])) {
		$SysMessage = ReadDB($OptionsLang["New_password_not_same"]); 
		$_REQUEST["act2"] = "changePass";
		$_REQUEST["act"] = "editProfile";
	} 	
	else {
		$sql = "UPDATE `".$TABLE["Users"]."` 
				SET `password` = '".($_REQUEST["newpassword"])."' 
				WHERE id = '".$UserId."'";
		$sql_result = sql_result($sql);
		
		// email to the user for password change	
		$mailheader = "From: ".$Options["email"]."\r\n";
		$mailheader .= "Reply-To: ".$Options["email"]."\r\n";
		$mailheader .= "Content-type: text/html; charset=utf-8\r\n";
		
		$msg_body = "Your new login details:<br>\n<br>\n";
		
		$msg_body .= ReadDB($OptionsLang["Login_Email"])." " . $User["useremail"] . "<br>\n" .
					 ReadDB($OptionsLang["Login_Password"])." " . $_REQUEST["newpassword"] . "<br><br>\n" .
					 ReadDB($OptionsLang["Screen_Name"])." " . $User["username"] . "<br>\n";
					 
		mail($User["useremail"], ReadDB($OptionsLang["Password_changed_subject"]), $msg_body, $mailheader);
		
		$SysMessage = ReadDB($OptionsLang["Password_changed"]);
		$_REQUEST["act2"] = "changePass";
		$_REQUEST["act"] = "editProfile";
	}


} elseif (isset($_POST["act"]) and $_POST["act"]=='post_comment') {	
	
	if ($Logged==true) { // if logged in, then you could submit comments
	
		if ($Options["approval"]=='true') {			
			$status = 'Not approved';
		} else {
			$status = 'Approved';
		}
		
		$WordAllowed = true;
		$BannedWords = explode(",", ReadDB($Options["ban_words"]));
		if (count($BannedWords)>0) {
		  $checkComment = strtolower($_REQUEST["comment"]);
		  for($i=0;$i<count($BannedWords);$i++){
			  $banWord = trim($BannedWords[$i]);
			  if (trim($BannedWords[$i])<>'') {
				  if(preg_match("/".$banWord."/i", $checkComment)){ 
					  $WordAllowed = false;
					  break;
				  }
			  }
		  }
		}
		
		
		$IPAllowed = true;
		$BannedIPs = explode(",", ReadDB($Options["ban_ips"]));
		if (count($BannedIPs)>0) {
		  $checkIP = strtolower($_SERVER["REMOTE_ADDR"]);
		  for($i=0;$i<count($BannedIPs);$i++){
			  $banIP = trim($BannedIPs[$i]);
			  if (trim($BannedIPs[$i])<>'') {
				  if(preg_match("/".$banIP."/i", $checkIP)){
					  $IPAllowed = false;
					  break;
				  }
			  }
		  }
		}
		
		// check for required fields
		$emptyReqField = true;
		if(trim($_REQUEST["name"])=='') {
			$emptyReqField = false;
		}
		if (!empty($Options["comm_req"]) and in_array("Email", $Options["comm_req"])) {
			if (trim($_REQUEST["email"])=='') { 
				$emptyReqField = false;
			}
		}
		if (trim($_REQUEST["comment"])=='') { 
			$emptyReqField = false;
		}
		
		if($WordAllowed==false) {
			 $Message =  $OptionsLang["Banned_word_used"]; 
		} elseif($IPAllowed==false) {
			 $Message = ReadDB($OptionsLang["Banned_ip_used"]); 
		} elseif($emptyReqField==false) {
			 $Message =  ReadDB($OptionsLang["required_fields"]);
		} else {
			
			$sql = "INSERT INTO ".$TABLE["Comments"]."
					SET `user_id` 		= '".SaveDB($_REQUEST['user_id'])."',  
						`publish_date` 	= '".$cur_date."',
						`ipaddress` 	= '".SafetyDB($_SERVER["REMOTE_ADDR"])."',
					  	`status` 		= '".$status."',
					  	`post_id` 		= '".SafetyDB($_REQUEST["pid"])."',
					  	`name` 			= '".SafetyDB($_REQUEST["name"])."',
					  	`email` 		= '".SafetyDB($_REQUEST["email"])."',
					  	`comment` 		= '".SafetyDB($_REQUEST["comment"])."'";
			$sql_result = sql_result($sql);
			$Message = $OptionsLang["Comment_Submitted"];
			if($Options['approval']=='true') {
				$Message .= $OptionsLang["After_Approval_Admin"];
			}
			
										
			$sql = "SELECT * FROM ".$TABLE["Posts"]." WHERE id='".SafetyDB($_REQUEST["pid"])."'";
			$sql_result = sql_result($sql);
			$Post = mysqli_fetch_assoc($sql_result);
			mysqli_free_result($sql_result);

			$mailheader = "From: ".ReadDB($Options["email"])."\r\n";
			$mailheader .= "Reply-To: ".ReadDB($Options["email"])."\r\n";
			$mailheader .= "Content-type: text/html; charset=UTF-8\r\n";
			$Message_body = "Post: <strong>".ReadDB($Post["post_title"])."</strong><br /><br />";
			$Message_body .= "Comment: <br /> ".nl2br(ReadDB($_REQUEST["comment"]))."<br /><br />";
			$Message_body .= "From: <br />".ReadDB($_REQUEST["email"])."<br />".ReadDB($_REQUEST["name"])."<br />";
			mail(ReadDB($Options["email"]), $OptionsLang["New_comment_posted"], $Message_body, $mailheader);
			
			unset($_REQUEST["name"]);
			unset($_REQUEST["email"]);
			unset($_REQUEST["comment"]);
			
			echo '<script type="text/javascript">window.location.href="'.$thisPage.'?pid='.$_REQUEST["pid"].'&p='.urlencode($_REQUEST["p"]).'&search='.urlencode($_REQUEST["search"]).'&cat_id='.$_REQUEST["cat_id"].'&Message='.urlencode($Message).'#comments";</script>'; 
		}

	} else {		
		$Message =  $OptionsLang["You_must_login"]; 
		unset($_REQUEST["act"]);
	}
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo $CONFIG["folder_name"]; ?>styles/ionicons.css" rel="stylesheet" />
<script src="<?php echo $CONFIG["full_url"]; ?>lightbox/js/jquery-1.11.0.min.js"></script>
<script src="<?php echo $CONFIG["full_url"]; ?>lightbox/js/lightbox.min.js"></script>
<link href="<?php echo $CONFIG["full_url"]; ?>lightbox/css/lightbox.css" rel="stylesheet" />
<?php include($CONFIG["server_path"]."styles/css_front_end.php"); ?>
<script type="text/javascript" src="<?php echo $CONFIG["full_url"]; ?>include/textsizer.js">
/***********************************************
* Document Text Sizer- Copyright 2003 - Taewook Kang.  All rights reserved.
* Coded by: Taewook Kang (http://www.txkang.com)
***********************************************/
</script>

<script type="text/javascript">
$( document ).on( 'click', '.loadmore', function () {
	 $(this).text('<?php echo $OptionsLang["LOADING"]; ?>');
	 var ele = $(this).parent('div');
	  $.ajax({
		url: '<?php echo $CONFIG["folder_name"]; ?>loadmore.php',
		type: 'POST',
		data: {
		  parameters:$(this).data('parameters'),
		},
		success: function(response){
		  if(response){
			ele.hide();
			$(".news_list").append(response);
		  }
		}
	  });
});
</script>

<a name="blt"></a>


<script type="text/javascript">
 var RecaptchaOptions = {
	theme : '<?php echo $Options['captcha_theme']; ?>'
 };
</script>

<div style="background-color:<?php echo $OptionsVis["gen_bgr_color"];?>;">
<div class="front_end_wrapper">
	
    
    <?php if($Options['showsearch']=='yes') {?> 
    <div class="search_form_wrap">   
        <div class="search_form">  
        <form action="<?php echo $thisPage; ?>" method="post" name="sform">              
              <input class="inputsearch" type="text" name="search" placeholder="<?php echo $OptionsLang["Search_button"]; ?>" value="<?php if(isset($_REQUEST["search"]) and $_REQUEST["search"]!='') echo htmlspecialchars(urldecode($_REQUEST["search"]), ENT_QUOTES); ?>">        
        </form>
        </div> 
    </div>
    <?php } ?>
    
    
	<?php	
	$sql = "SELECT * FROM ".$TABLE["Categories"]." ORDER BY cat_name ASC";
	$sql_result = sql_result($sql);
	if (mysqli_num_rows($sql_result)>0) {
	?>
	<div class="dropdown dropdown2">
      <button class="dropbtn"><?php echo $OptionsLang["Category"]; ?></button>
      <div class="dropdown-content">
        <a href="?cat_id=0"><?php echo $OptionsLang["Category_all"]; ?></a>
        <?php 
        $sql = "SELECT * FROM ".$TABLE["Categories"]." ORDER BY cat_name ASC";
        $sql_result = sql_result($sql);
        while ($Cat = mysqli_fetch_assoc($sql_result)) { ?>
        <a href="<?php echo $thisPage; ?>?cat_id=<?php echo $Cat["id"]; ?>"><?php echo $Cat["cat_name"]; ?></a>
        <?php } ?>
      </div>
    </div>
    <?php } ?>
    
    <div class="dist_search_title"></div>

<?php
if (isset($_REQUEST["pid"]) and $_REQUEST["pid"]>0) {	
	$_REQUEST["pid"]= (int) SafetyDB($_REQUEST["pid"]);
	
	$sql = "SELECT * FROM ".$TABLE["Posts"]." WHERE id='".SafetyDB($_REQUEST["pid"])."' and status='Posted'";
	$sql_result = sql_result($sql);
	$Post = mysqli_fetch_assoc($sql_result);
	$CurrPubDate = $Post["publish_date"];
	mysqli_free_result($sql_result);
	
	// fetch post category
	$sqlCat   = "SELECT * FROM ".$TABLE["Categories"]." WHERE `id`='".$Post["cat_id"]."'";
	$sql_resultCat = sql_result($sqlCat);
	$Cat = mysqli_fetch_array($sql_resultCat);
?>
    <!-- 'Back' link -->
    <div class="back_link">
        <a href="<?php echo $thisPage; ?>?p=<?php echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php echo urlencode($_REQUEST["search"]); ?>#blt"> <div class="arrow-left"></div> <?php echo $OptionsLang["Back_home"]; ?>
        </a>
    </div>
    
    <!-- post title -->
    <div class="post_title"><?php echo $Post["post_title"]; ?></div>
    
    <div class="dist_title_date"></div>
    
    <!-- post date --> 
    <?php if($OptionsVis["show_date"]!='no' or $OptionsVis["show_aa"]!='no' or $Cat["Cat"]>0) { ?>   
    <div class="date_style">
    	<?php if($Cat["cat_name"]!="") echo $Cat["cat_name"]." / "; ?>
    	<?php if($OptionsVis["show_date"]!='no') { ?>  
        <?php echo lang_date(date($OptionsVis["date_format"],strtotime($Post["publish_date"]))); ?> 
        <?php if($OptionsVis["showing_time"]!='') echo date($OptionsVis["showing_time"],strtotime($Post["publish_date"])); ?>
        <?php } ?>
        <?php if($OptionsVis["show_aa"]!='no') { ?>
        &nbsp;&nbsp;&nbsp;&nbsp;<a style="text-decoration:none;color:#999;font-size:<?php echo $OptionsVis["date_size"];?>;" href="javascript:ts('post_text',+1)">A<sup>+</sup></a> | <a style="text-decoration:none;color:#999;font-size:<?php echo $OptionsVis["date_size"];?>;" href="javascript:ts('post_text',-1)">a<sup>-</sup></a>
        <?php } ?>
    </div>
    <?php } ?>
    
    <div class="dist_date_text"></div>
    
    <!-- post text --> 
    <div id="post_text" class="post_text"><?php echo $Post["post_text"]; ?></div>
    <div class="clearboth"></div>  


	<?php 
	$sql = "UPDATE ".$TABLE["Posts"]." 
			SET reviews = reviews + 1 
			WHERE id='".SafetyDB($Post["id"])."'";
	$sql_result = sql_result($sql);	
	?>
    
    <?php if($Options["showshare"]=='yes') { ?>
    <div class="share_buttons">
        <!-- AddToAny BEGIN -->
		<style type="text/css">
        a .a2a_svg { -webkit-filter: invert(1); filter: invert(1); }
        </style>
        <div class="a2a_kit a2a_kit_size_28 a2a_default_style" data-a2a-icon-color="black">
        <a class="a2a_dd" href="https://www.addtoany.com/share_save"></a>
        <a class="a2a_button_facebook"></a>
        <a class="a2a_button_twitter"></a>
        <a class="a2a_button_google_plus"></a>
        <a class="a2a_button_email"></a>
        <a class="a2a_button_print"></a>
        </div>
        <script type="text/javascript" src="//static.addtoany.com/menu/page.js"></script>
        <!-- AddToAny END -->
	</div>
    <?php } ?>
    
    
    <div class="clearboth"></div>
    
    <!-- LATEST 3 POSTS START HERE -->
    
    <div class="Latest3posts"><?php echo ReadDB($OptionsLang["LATEST_POSTS"]); ?></div>
    
    <?php 
	$sqlLat = "SELECT * FROM ".$TABLE["Posts"]." 
			WHERE status<>'Hidden' " .$search . " AND id!='".SafetyDB($Post["id"])."' 
			ORDER BY publish_date DESC 
			LIMIT 0,3";	
	$sql_resultLat = sql_result($sqlLat);
	$i = 1;
	
	$numOfLat = mysqli_num_rows($sql_resultLat);
	if($numOfLat>0) {
	  while ($LatPost = mysqli_fetch_assoc($sql_resultLat)) {
		//comments number
		$sqlCm   = "SELECT count(*) as total FROM ".$TABLE["Comments"]." WHERE `post_id`='".$LatPost["id"]."' AND status='Approved'";
		$sql_resultCm = sql_result($sqlCm);
		$countCm = mysqli_fetch_array($sql_resultCm);
		
		$show_image = 0;
	  	if(preg_match('@<img.+src="(.*)".*>@Uims', $LatPost["post_text"], $matches)) {
			$src = $matches[1];
			$show_image = 1;
	  	}
	?>
    	<div class="dbl-third-padd-float">
        
          <div class="dbl-box-shadow">
          
          	<?php if($show_image==1) {?>
              <a class="dbl-image-wrapper-grid" href="<?php echo $thisPage; ?>?pid=<?php echo $LatPost['id']; ?>">
                <div class="dbl-image-grid" style="background-image:url('<?php echo $src; ?>');">
                </div>
              </a>
           	<?php } ?>
                
              <div class="dbl-title-descr-grid">
                <a class="dbl-title-grid" href="<?php echo $thisPage; ?>?pid=<?php echo $LatPost['id']; ?>"><?php echo ReadDB($LatPost["post_title"]); ?></a>
                <div class="dbl-grid-dist-title-date"></div>
                
                <!-- Post date -->     
                <div class="dbl-grid-date-style">
                    <i class="ion-ios-clock"></i>
                    <?php echo lang_date(date($OptionsVis["list_date_format"],strtotime($LatPost["publish_date"]))); ?> 
                    <?php if($OptionsVis["list_showing_time"]!='') echo date($OptionsVis["list_showing_time"],strtotime($LatPost["publish_date"])); ?>
                </div>
                                   
                <a class="dbl-comments-num-link" href="<?php echo $thisPage; ?>?pid=<?php echo $LatPost['id']; ?>#comments"><i class="ion-android-chat"></i> <?php echo $countCm["total"]; ?></a>
				
                <div class="dbl-grid-dist-date-text"></div>
                
              </div>
              
          </div>
          <div class="dist_btw_posts"></div>
        </div>
    
    <?php 
		$i++;
	  }
	}
	?>
    
    <!-- LATEST 3 POSTS END HERE -->
    
    
    <div class="clearboth"></div>
    <a name="comments"></a>

	<?php if($Post['post_comments']=='true') { ?> 


    <?php if(isset($Message)) { ?>
    <div class="comment_message"><?php if(isset($Message)) echo $Message; ?></div>
    <?php } else { ?>
    <div class="comment_message"><?php if(isset($_REQUEST['Message'])) echo urldecode($_REQUEST['Message']); ?></div>
    <?php } ?>
    
    <?php
    if ($Options["comments_order"]=='OnTop') {
        $commentOrder = 'DESC';
    } else {
        $commentOrder = 'ASC';
    }
    
    $sql = "SELECT * FROM ".$TABLE["Comments"]." WHERE post_id='".$Post["id"]."' AND status='Approved' ORDER BY id ".$commentOrder;
    $sql_result = sql_result($sql);
    $numComments = mysqli_num_rows($sql_result);
    if ($numComments>0) { 
        if ($Options["comments_order"]=='OnTop') {
            $commentNum = $numComments;
        } else {
            $commentNum = 1;
        }
    ?>
    <div class="word_Comments"><?php echo $numComments; ?> <?php echo $OptionsLang["Word_Comments"];?></div>
    <?php
        while ($Comments = mysqli_fetch_assoc($sql_result)) {
			$sqlU = "SELECT * FROM ".$TABLE["Users"]." WHERE id='".$Comments["user_id"]."'";
			$sql_resultU = sql_result($sqlU);
			$User = mysqli_fetch_assoc($sql_resultU);
    ?>
    <!-- comments wrap div -->
    <div class="comments_wrapper">
        
        
        <?php if(stripslashes($User["image"]) != "") { ?> 
            <div class="padd_bott2" style="float: left; padding: 6px 1.5% 0 0;"><img class="avatar_img" src="<?php echo $CONFIG["full_url"].$CONFIG["upload_folder"].ReadDB($User["image"]); ?>" /></div>
        <?php } else { ?> 
            <div class="padd_bott2" style="float: left; padding: 6px 1.5% 0 0;"><img class="avat_no_img" src="<?php echo $CONFIG["full_url"]; ?>images/no_image.png" /></div>
        <?php } ?>  
        
        
        <!-- comments name -->
        <div style="float:left;padding-bottom:8px;color:<?php echo $OptionsVisC["name_font_color"];?>;font-size:<?php echo $OptionsVisC["name_font_size"];?>;font-style:<?php echo $OptionsVisC["name_font_style"];?>;font-weight:<?php echo $OptionsVisC["name_font_weight"];?>;"><?php echo ReadHTML($Comments["name"]); ?></div>
        
        <div style="float:right; padding-left:10px;"><span style="font-weight:bold;padding-right:2px;">#</span><?php echo $commentNum; ?></div>
        
        <!-- comments date -->
        <div style="color:<?php echo $OptionsVisC["comm_date_color"];?>; font-family:<?php echo $OptionsVisC["comm_date_font"];?>; font-size:<?php echo $OptionsVisC["comm_date_size"];?>;font-style: <?php echo $OptionsVisC["comm_date_font_style"];?>; float:right;">		
			<?php 
				if($OptionsVisC["comm_showing_time"]!='') { 
					$show_time = " ".$OptionsVisC["comm_showing_time"]; 
				} else {
					$show_time = "";
				}
				
				if(isset($OptionsVisC["time_offset"]) and $OptionsVisC["time_offset"]!='0') { 						
					echo lang_date(date($OptionsVisC["comm_date_format"].$show_time,strtotime($OptionsVisC["time_offset"], strtotime($Comments["publish_date"]))));
				} else {
					echo lang_date(date($OptionsVisC["comm_date_format"].$show_time,strtotime($Comments["publish_date"])));
				}
			?>
        </div>
                
        <!-- comments text -->
        <div style="color:<?php echo $OptionsVisC["comm_font_color"];?>;font-size:<?php echo $OptionsVisC["comm_font_size"];?>;font-style:<?php echo $OptionsVisC["comm_font_style"];?>;font-weight:<?php echo $OptionsVisC["comm_font_weight"];?>; float: left; width: 87%;"><?php echo ReadHTML(nl2br($Comments["comment"])); ?></div>
    
    </div>
    
    <div style="clear:both;height:<?php echo $OptionsVisC["dist_btw_comm"];?>;"></div>
    
    <?php
            if ($Options["comments_order"]=='OnTop') {
                $commentNum --;
            } else {
                $commentNum ++;
            }
        }
    } else {
    ?>
    <div  style="padding-bottom:10px;padding-top:10px;font-weight:bold;clear:both;"><?php echo $OptionsLang["No_comments_posted"]; ?></div>
    <?php 
    }
	mysqli_free_result($sql_result);
    ?>   
    
    <a name="profile"></a>
    <?php if(isset($SysMessage)) { ?>
    <div class="comment_message"><?php if(isset($SysMessage)) echo $SysMessage; ?></div>
    <?php } else { ?>
    <div class="comment_message"><?php if(isset($_REQUEST['SysMessage'])) echo urldecode($_REQUEST['SysMessage']); ?></div>
    <?php } ?>
    <?php if ( $Logged ){ ?>
    
    
    <div style="padding:16px 0; text-align:right;">
    	<?php if(isset($_REQUEST["act"]) and $_REQUEST["act"]=="editProfile") { ?>
    	<a href="<?php echo $thisPage; ?>?pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Submit_Comment_link"]); ?></a>
        <?php } else { ?>
        <a href="<?php echo $thisPage; ?>?act=editProfile&pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Edit_Profile_button"]); ?></a>
        <?php } ?>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="<?php echo $thisPage; ?>?act=logout&pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Logout_button"]); ?></a></div>
    <?php } else {?>
    <div style="padding:16px 0; text-align:right;"><a href="<?php echo $thisPage; ?>?act=loginform&pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Login_button"]); ?></a> &nbsp; | &nbsp; <a href="<?php echo $thisPage; ?>?act=register&pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Sign_Up_button"]); ?></a></div>
    <?php } ?>
    
	<?php 
    // begin login if is looged
    if ( $Logged and !isset($_REQUEST["act"]) ){
        $sql = "SELECT * FROM ".$TABLE["Users"]." WHERE id='".$UserId."'";
       	$sql_result = sql_result($sql);	
        $User = mysqli_fetch_assoc($sql_result);	
		
			
    ?>
    
    <script type="text/javascript">
    function checkComment(form){
        var chekmail = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
    
        var name, email, comment, isOk = true;
		
        var message = "";
        
        message = "<?php echo $OptionsLang["required_fields"]; ?>";
        
        name	= form.name.value;	
		<?php if (!empty($Options["comm_req"]) and in_array("Email", $Options["comm_req"])) { ?>
        email	= form.email.value;
		<?php } ?>
        comment	= form.comment.value;
        <?php if($Options['captcha']!='recap' and $Options['captcha']!='nocap') { // if the option is NOT set to reCaptcha or no captcha ?>
		string	= form.string.value;
		<?php } ?>
    
        if (name.length==0){
            form.name.focus();
            isOk=false;
        }
		<?php if (!empty($Options["comm_req"]) and in_array("Email", $Options["comm_req"])) { ?>
        else if (email.length<5){
            form.email.focus();
            isOk=false;
        }	
        else if (email.length>=5 && email.match(chekmail)==null){
            message ="<?php echo $OptionsLang["correct_email"]; ?>";
            form.email.focus();
            isOk=false;
        }
		<?php } ?>
        else if (comment.length==0){
            form.comment.focus();
            isOk=false;
        }
    
        if (!isOk){			   
            alert(message);
            return isOk;
        } else {
            return isOk;
        }
    }
    </script>
    <script type="text/javascript">
	 var RecaptchaOptions = {
		theme : '<?php echo $Options['captcha_theme']; ?>'
	 };
	</script>
    <!-- comments form -->
    <form action="<?php echo $thisPage; ?>?p=<?php echo $_REQUEST['p']; ?>&cat_id=<?php echo $_REQUEST["cat_id"]; ?>&search=<?php echo urlencode($_REQUEST["search"]); ?>#comments" name="formComment" method="post" style="margin:0;padding:0;">
    <input type="hidden" name="pid" value="<?php echo $_REQUEST["pid"]; ?>" />
    <input type="hidden" name="act" value="post_comment" />
    <input type="hidden" name="name" value="<?php echo $User["username"]; ?>" />
    <input type="hidden" name="email" value="<?php echo $User["useremail"]; ?>" /> 
    <input type="hidden" name="user_id" value="<?php echo $User["id"]; ?>" /> 
    <table class="comments_wrapper">
      <tr>
        <td class="leave_comment"><?php echo $OptionsLang["Leave_Comment"]; ?></td>
      </tr>
      <tr>    
        <td valign="top" class="comment_fields">
        	<textarea placeholder="<?php echo $OptionsLang["Comment_here"]; ?>" name="comment" rows="5" class="form_fields"><?php if(isset($_REQUEST["comment"])) echo $_REQUEST["comment"]; ?></textarea>
        </td>
      </tr>
      
      <tr>
        <td class="comment_required">* - <?php echo $OptionsLang["Required_fields"]; ?></td>
      </tr>
      <tr>
        <td class="comment_button"><input type="submit" name="button" value="<?php echo $OptionsLang["Submit_Comment"]; ?>" onclick="return checkComment(this.form)" class="submitbtn" /></td>
      </tr>
    </table>
    </form>
    
    <?php } elseif(isset($_REQUEST["act"]) and $_REQUEST['act']=="register") { /////////// REGISTRATION PASSWORD BOX ///////////// ?>

	<script type="text/javascript">
    
    function trim(str, chars) {
        return ltrim(rtrim(str, chars), chars);
    }
     
    function ltrim(str, chars) {
        chars = chars || "\\s";
        return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
    }
     
    function rtrim(str, chars) {
        chars = chars || "\\s";
        return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
    }
    
    function checkReg(form){
        var chekmail = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
    
        var useremail, password, username, isOk = true;
		
		<?php if($Options['captcha']=='capmath' or $Options['captcha']=='cap' or $Options['captcha']=='vsc') { // if the option is set to Math or Simple or Very Simple Captcha ?>
        var string;
        <?php } ?>
        
        var message = "";
        
        message = "<?php echo ReadDB($OptionsLang["required_fields"]); ?>";
        
		useremail	= form.useremail.value;	
        useremail	= trim(useremail);
		
		password	= form.password.value;	
        password	= trim(password);

        username	= form.username.value;	
        username	= trim(username);	
		
		<?php if($Options['captcha']=='capmath' or $Options['captcha']=='cap' or $Options['captcha']=='vsc') { // if the option is set to Math or Simple or Very Simple Captcha ?>
        string	= form.string.value;
        <?php } ?>
		
		if (useremail.length==0){
            form.useremail.focus();
            isOk=false;
        }	
        else if (useremail.length>=5 && useremail.match(chekmail)==null){
            message ="<?php echo ReadDB($OptionsLang["correct_email"]); ?>";
            form.useremail.focus();
            isOk=false;
        }
		
		else if (password.length==0){
            form.password.focus();
            isOk=false;
        }
        
        else if (username.length==0){
            form.username.focus();
            isOk=false;
        }  
		
		<?php if($Options['captcha']=='capmath' or $Options['captcha']=='cap' or $Options['captcha']=='vsc') { // if the option is set to Math or Simple or Very Simple Captcha ?>
        else if (string.length==0){
            message ="<?php echo ReadDB($OptionsLang["field_code"]); ?>";
            form.string.focus();
            isOk=false;
        }
        <?php } ?>	     
    
        if (!isOk){			  
            alert(message);
            return isOk;
        } else {
            return isOk;
        }
    }
    
    function limitText(limitField, limitCount, limitNum) {
        if (limitField.value.length > limitNum) {
            limitField.value = limitField.value.substring(0, limitNum);
        } else {
            limitCount.value = limitNum - limitField.value.length;
        }
    }
    </script>
	
	
    <form action="<?php echo $thisPage; ?>#profile" method="post" name="form" enctype="multipart/form-data">
	<input type="hidden" name="act" value="addUser" />
    <input type="hidden" name="pid" value="<?php if(isset($_REQUEST["pid"])) echo $_REQUEST['pid']; ?>">
    <table class="comments_wrapper">
      <tr>
    	<td style="padding:12px;"><?php echo ReadDB($OptionsLang["For_registration_please"]); ?></td>
      </tr>            
      <tr>
        <td class="comment_fields"><input type="text" name="useremail" value="<?php if(isset($_REQUEST["useremail"])) echo $_REQUEST["useremail"]; ?>" class="form_fields form_field_50" placeholder="<?php echo ReadDB($OptionsLang["Login_Email"]); ?>" /></td>
      </tr>
    
      <tr>
        <td class="comment_fields"><input type="password" name="password" class="form_fields form_field_50" placeholder="<?php echo ReadDB($OptionsLang["Login_Password"]); ?>" /></td>
      </tr>
    
      <tr>
        <td class="comment_fields"><input type="text" name="username" value="<?php if(isset($_REQUEST["username"])) echo $_REQUEST["username"]; ?>" class="form_fields form_field_50" placeholder="<?php echo ReadDB($OptionsLang["Screen_Name"]); ?>" /></td>
      </tr>
    
      <tr>
        <td class="comment_fields"><?php echo ReadDB($OptionsLang["Reg_Avatar"]); ?>&nbsp;<input type="file" name="image" size="40" class="form_upload" placeholder="<?php echo ReadDB($OptionsLang["Reg_Avatar"]); ?>" /></td>
      </tr>
      
      
      <?php 
	  if($Options['captcha']!='nocap') { // if the option is set to no Captcha
	  ?> 
      <tr>
        <td class="comment_fields">
        	<div><strong><?php echo $OptionsLang["Enter_verification_code"]; ?>*</strong></div>
        	<?php if($Options['captcha']=='recap') { // if the option is set to reCaptcha
				$publickey = "6Lfk9L0SAAAAACp13Wlzz6WTanYxrcLBXyn7XNSJ";
				echo recaptcha_get_html($publickey, $error);
			} elseif($Options['captcha']=='capmath') { ?>
				<img src="<?php echo $CONFIG["folder_name"]; ?>captchamath.php" class="form_captcha_img" alt="Mathematical catpcha image" />
				<div class="form_captcha_eq"> = </div>
				<input type="text" name="string" maxlength="3" class="form_captcha form_captcha_math" />
			<?php } elseif($Options['captcha']=='cap') {  ?>
				<img src="<?php echo $CONFIG["folder_name"]; ?>captcha.php" class="form_captcha_img" alt="Simple catpcha image" /> <input type="text" name="string" maxlength="7" class="form_captcha form_captcha_s" /> <div class="form_asterisk">*</div>
			<?php } else { ?>
				<img src="<?php echo $CONFIG["folder_name"]; ?>captchasimple.php" class="form_captcha_img" alt="Very catpcha image" /> <input type="text" name="string" maxlength="7" class="form_captcha form_captcha_s" /> <div class="form_asterisk">*</div>
			<?php } ?>
        </td>
      </tr>
      <?php 
	  }
	  ?>
    
      <tr>
        <td class="comment_fields">* - <?php echo ReadDB($OptionsLang["Required_fields"]); ?></td>
      </tr>
    
      <tr>
        <td class="comment_fields">
        	<input name="submit" type="submit" value="<?php echo ReadDB($OptionsLang["Sign_Up_button"]); ?>" class="submitbtn" onclick="return checkReg(this.form)" />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <a href="<?php echo $thisPage; ?>?act=forgot&pid=<?php echo $Post["id"]; ?>#comments" class="reg_link"><?php echo ReadDB($OptionsLang["Forgot_password"]); ?></a>
        </td>
      </tr>
    </table>


	<?php } elseif(isset($_REQUEST["act"]) and $_REQUEST['act']=="forgot") { /////////// FORGOT PASSWORD BOX /////////// ?>
   	
    
    <form action="<?php echo $thisPage; ?>#profile" method="post" name="form" enctype="multipart/form-data">
    <input type="hidden" name="act" value="sendPass" />
    <input type="hidden" name="pid" value="<?php if(isset($_REQUEST["pid"])) echo $_REQUEST['pid']; ?>">
    <table class="comments_wrapper">
      <tr>
        <td style="padding:12px;"><?php echo ReadDB($OptionsLang["Please_enter_your_email_address"]); ?></td>
      </tr>            
      <tr>
      	<td class="comment_fields"><input type="text" name="useremail" size="40" value="<?php if(isset($_REQUEST["useremail"])) echo $_REQUEST["useremail"]; ?>" class="form_fields form_field_50" placeholder="<?php echo ReadDB($OptionsLang["Login_Email"]); ?>" /></td>
      </tr>

        
      <tr>
      	<td class="comment_fields">
        	<input name="submit" type="submit" value="<?php echo ReadDB($OptionsLang["Send_Pass_button"]); ?>" class="submitbtn" />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <a href="<?php echo $thisPage; ?>?act=register&pid=<?php echo $Post["id"]; ?>#comments" class="reg_link"><?php echo ReadDB($OptionsLang["Sign_Up_button"]); ?></a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="<?php echo $thisPage; ?>?pid=<?php echo $Post["id"]; ?>#comments" class="reg_link"><?php echo ReadDB($OptionsLang["Login_button"]); ?></a>
        </td>
      </tr>
    </table>
    </form>
    
    
    <?php } elseif(isset($_REQUEST["act"]) and $_REQUEST['act']=="editProfile" and $Logged) { 
		$sql = "SELECT * FROM ".$TABLE["Users"]." WHERE id='".$UserId."'";
		$sql_result = sql_result($sql);
		$User = mysqli_fetch_assoc($sql_result);	
	?>
            
	<table class="comments_wrapper">
      <tr>
        <td align="left" valign="top" style="padding-top:16px;">
            
            <table width="100%" border="0" cellspacing="0" cellpadding="0">    
                <tr>
                  <td colspan="2" align="center"><strong>Hello <?php echo ReadDB($User['username']); ?></strong></td>
                </tr>      
            </table>
            
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left" style="padding-bottom:12px;padding-top:12px;"><a href="<?php echo $thisPage; ?>?act=editProfile&pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Change_avatar_link"]); ?></a></td>
                  <td align="right" style="padding-bottom:12px;padding-top:12px;"><a href="<?php echo $thisPage; ?>?act=editProfile&act2=changePass&pid=<?php echo $Post["id"]; ?>#profile" class="reg_link"><?php echo ReadDB($OptionsLang["Change_Password_link"]); ?></a></td>
                </tr>        
            </table>
        
        
        <?php if ($_REQUEST["act"]=="editProfile" and isset($_REQUEST["act2"]) and $_REQUEST["act2"]=='changePass') { ?>
            <form action="<?php echo $thisPage; ?>?act=editProfile&act2=changePass#comments" method="post" name="form">
             <input type="hidden" name="act" value="updatePass" />
    		 <input type="hidden" name="pid" value="<?php if(isset($_REQUEST["pid"])) echo $_REQUEST['pid']; ?>">
             
             <table width="100%" border="0" cellspacing="0" cellpadding="5">
                
                <tr>
                  <td style="padding:12px;"><?php echo ReadDB($OptionsLang["For_changing_password_please"]); ?></td>
                </tr>
                        
                <tr>
                  <td class="comment_fields"><input type="text" name="oldpassword" class="form_fields form_field_60" placeholder="<?php echo ReadDB($OptionsLang["Old_password"]); ?>" /></td>
                </tr>

                
                <tr>
                  <td class="comment_fields"><input type="text" name="newpassword" class="form_fields form_field_60" placeholder="<?php echo ReadDB($OptionsLang["New_password"]); ?>" /></td>
                </tr>
                
                <tr>
                  <td class="comment_fields"><input type="text" name="newpassword2" class="form_fields form_field_60" placeholder="<?php echo ReadDB($OptionsLang["New_password_confirm"]); ?>" /></td>
                </tr>
                            
                <tr>
                  <td class="comment_fields"><input name="submit" type="submit" value="<?php echo ReadDB($OptionsLang["Change_Password_button"]); ?>" class="submitbtn" /></td>
                </tr>
              </table>
            </form>
        
        
        <?php } else { ?>
        <form action="<?php echo $thisPage; ?>?act=editProfile#comments" method="post" name="form" enctype="multipart/form-data">
         <input type="hidden" name="act" value="updateAvatar" />
    	 <input type="hidden" name="pid" value="<?php if(isset($_REQUEST["pid"])) echo $_REQUEST['pid']; ?>">
         <table width="100%" border="0" cellspacing="0" cellpadding="5" style="font-family:<?php echo $OptionsVis["gen_font_family"];?>; font-size:<?php echo $OptionsVis["gen_font_size"];?>;margin:0 auto; color:<?php echo $OptionsVis["gen_font_color"];?>;">
            
            <tr>
              <td style="padding:12px;" colspan="2"><?php echo ReadDB($OptionsLang["For_changing_avatar_please"]); ?></td>
            </tr>   
                    
            <tr>
              <td class="log_left"><?php echo ReadDB($OptionsLang["Login_Email"]); ?></td>
              <td class="comment_fields"><strong><?php echo ReadDB($User["useremail"]); ?></strong></td>
            </tr>
            
            <tr>
              <td class="log_left"><?php echo ReadDB($OptionsLang["Screen_Name"]); ?></td>
              <td class="comment_fields"><strong><?php echo ReadDB($User["username"]); ?></strong></td>
            </tr>
            
            <tr>
              <td class="log_left"><?php echo ReadDB($OptionsLang["Reg_Avatar"]); ?></td>
              <td class="comment_fields">
                <?php if(stripslashes($User["image"]) != "") { ?>
                <img src="<?php echo $CONFIG["full_url"].$CONFIG["upload_folder"].ReadDB($User["image"]); ?>" border="0" /> 			&nbsp;&nbsp;<a href="<?php $_SERVER["PHP_SELF"]; ?>?act=editProfile&amp;act2=delImage&pid=<?php echo $Post["id"]; ?>#profile" class="linkki"><?php echo ReadDB($OptionsLang["delete_avatar"]); ?></a><br /> 
                <?php echo ReadDB($OptionsLang["If_you_upload_new_avatar"]); ?> <br />
                <?php } ?>
                <input type="file" name="image" size="50%" />
              </td>
            </tr>
                   
            <tr>
              <td class="log_left">&nbsp;</td>
              <td class="comment_fields"><input name="submit" type="submit" value="<?php echo ReadDB($OptionsLang["Update_Avatar_button"]); ?>" class="submitbtn" /></td>
            </tr>
          </table>
        </form>
        <?php 
        } 
        ?>
        
        </td>
      </tr>
    </table> 
    
    
    <?php 
	} else { /////////// LOGIN BOX
	?>
    
    <form action="<?php echo $thisPage; ?>#profile" method="post">
    <input type="hidden" name="act" value="login">
    <input type="hidden" name="pid" value="<?php if(isset($_REQUEST["pid"])) echo $_REQUEST['pid']; ?>">
    <table class="comments_wrapper">
      <tr>
        <td style="padding:12px;"><?php echo ReadDB($OptionsLang["You_must_login"]); ?></td>
      </tr>

      <tr>
        <td class="comment_fields"><input name="useremail" type="text" class="form_fields form_field_60" placeholder="<?php echo ReadDB($OptionsLang["Login_Email"]); ?>" /></td>
      </tr>
      <tr>
        <td class="comment_fields"><input name="password" type="password" class="form_fields form_field_60" placeholder="<?php echo ReadDB($OptionsLang["Login_Password"]); ?>" /></td>
      </tr>
      <tr>
        <td class="comment_fields">
            <input type="submit" name="button" value="<?php echo ReadDB($OptionsLang["Login_button"]); ?>" class="submitbtn" /> 
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <a href="<?php echo $thisPage; ?>?act=register&pid=<?php echo $Post["id"]; ?>#comments" class="reg_link"><?php echo ReadDB($OptionsLang["Sign_Up_button"]); ?></a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <a href="<?php echo $thisPage; ?>?act=forgot&pid=<?php echo $Post["id"]; ?>#comments" class="reg_link"><?php echo ReadDB($OptionsLang["Forgot_password"]); ?></a>
        </td>
      </tr>     
    </table>
    </form>
    
    <?php 
	} /////////// END LOGIN BOX
	?>   
    
    
    <?php 
    } // end if comments true
    ?>
    
    
    <?php if(trim($OptionsLang["Older_Post"])!='' or trim($OptionsLang["Home_bottom"])!='' or trim($OptionsLang["Newer_Post"])!='') {?>
    <!-- navigation at the bottom "Older Post", "Home", "Newer Post" -->    
    <table class="bottom_navigator">
      <tr>
      	<?php 
		$Older_Post = '';
		$sql = "SELECT * FROM ".$TABLE["Posts"]." 
		WHERE `publish_date`<'".$CurrPubDate."' 
		AND status='Posted' " .$search . " 
		ORDER BY publish_date DESC LIMIT 0,1";
		$sql_result = sql_result($sql);
		if(mysqli_num_rows($sql_result)>0) {
			$Post = mysqli_fetch_assoc($sql_result);
			$Older_Post = $Post['id'];
		}	
		mysqli_free_result($sql_result);
		?>
        <td class="older_post">
        	<?php if($Older_Post>0) {?>
        		<a class="nav_active" href="<?php echo $thisPage; ?>?pid=<?php echo $Older_Post; ?>&amp;p=<?php echo $_REQUEST['p']; ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php echo urlencode($_REQUEST["search"]); ?>#blt"><?php echo $OptionsLang["Older_Post"]; ?></a>
			<?php } else { ?>
            	<span class="nav_inactive"><?php echo $OptionsLang["Older_Post"]; ?></span>
            <?php } ?>
        </td>
        
        <td class="home_post"><a class="nav_active" href="<?php echo $thisPage; ?>?p=<?php echo $_REQUEST['p']; ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php echo urlencode($_REQUEST["search"]); ?>#blt"><?php echo $OptionsLang["Home_bottom"]; ?></a></td>
        
        <?php 
		$Newer_Post = '';
		$sql = "SELECT * FROM ".$TABLE["Posts"]." 
				WHERE `publish_date`>'".$CurrPubDate."' 
				AND status='Posted' " .$search . " 
				ORDER BY publish_date ASC LIMIT 0,1";
		$sql_result = sql_result($sql);
		if(mysqli_num_rows($sql_result)>0) {
			$Post = mysqli_fetch_assoc($sql_result);
			$Newer_Post = $Post['id'];
		}	
		mysqli_free_result($sql_result);
		?>
        <td class="newer_post">
            <?php if($Newer_Post>0) {?>
        		<a class="nav_active" href="<?php echo $thisPage; ?>?pid=<?php echo $Newer_Post; ?>&amp;p=<?php echo $_REQUEST['p']; ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php echo urlencode($_REQUEST["search"]); ?>#blt"><?php echo $OptionsLang["Newer_Post"]; ?></a>
			<?php } else { ?>
            	<span class="nav_inactive"><?php echo $OptionsLang["Newer_Post"]; ?></span>
            <?php } ?>
        </td>
        
      </tr>
    </table>
    <?php } ?>


<?php
} else {
?>

  <div class="news_list">
  	<?php 
	$sql = "SELECT * FROM ".$TABLE["Posts"]." 
			WHERE status<>'Hidden' " .$search . "  
			ORDER BY publish_date DESC 
			LIMIT 0," . $Options["per_page"];	
	$sql_result = sql_result($sql);
	//echo $sql;
	//echo "<br>";
	$numOfPosts = mysqli_num_rows($sql_result);
	//echo $numOfPosts;
	if($numOfPosts>0) {
	  while ($Post = mysqli_fetch_assoc($sql_result)) {
		//comments number
		$sqlC   = "SELECT count(*) as total FROM ".$TABLE["Comments"]." WHERE `post_id`='".$Post["id"]."' AND status='Approved'";
		$sql_resultC = sql_result($sqlC);
		$count = mysqli_fetch_array($sql_resultC);
		// fetch post category
		$sqlCat   = "SELECT * FROM ".$TABLE["Categories"]." WHERE `id`='".$Post["cat_id"]."'";
		$sql_resultCat = sql_result($sqlCat);
		$Cat = mysqli_fetch_array($sql_resultCat);
?>
	
    <div class="post_list_wrapper">
    	
        <!-- Post title -->
    	<div class="list_post_title"><a href="<?php echo $thisPage; ?>?pid=<?php echo $Post["id"]; ?>&amp;p=<?php if(isset($_REQUEST["p"])) echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php if(isset($_REQUEST["search"])) echo urlencode($_REQUEST["search"]); ?>#blt"><?php echo $Post["post_title"]; ?></a></div>    
    
        <div class="list_dist_title_date"></div>
        
        <!-- Post date -->   
        <?php if($OptionsVis["list_show_date"]!='no' or (isset($Cat["Cat"]) and $Cat["Cat"]>0)) { ?>  
        <div class="list_date_style">
        	<?php if($Cat["cat_name"]!="") echo $Cat["cat_name"]." / "; ?>
			<?php echo lang_date(date($OptionsVis["list_date_format"],strtotime($Post["publish_date"]))); ?> 
			<?php if($OptionsVis["list_showing_time"]!='') echo date($OptionsVis["list_showing_time"],strtotime($Post["publish_date"])); ?>
        </div>
        <?php } ?>
        
        <div class="list_dist_date_text"></div>
        
        <!-- Post text --> 
        <div class="list_post_text">
            <?php 			
			if(trim($Post["post_limit"])=='') {
				echo $Post["post_text"];
			} elseif(trim($Post["post_limit"])>0) {
				//$output = strip_only(cutStrHTML(ReadDB($Post["post_text"]), 0, $Post["post_limit"]), "div"); 
				if (isCyrillic($Post["post_text"])) {	
				  $output = truncateBlogHtml($Post["post_text"], $Post["post_limit"]);
				} else {
				  $output = TruncateHTML::truncateChars($Post["post_text"], $Post["post_limit"], '...');
				}
				echo $output;
			}
			?> 
      </div>
        
        
        
        <?php 
		$sqlNum = "SELECT * FROM ".$TABLE["Comments"]." WHERE post_id='".$Post["id"]."' AND status='Approved'";
		$sql_resultNum = sql_result($sqlNum);
		$numComments = mysqli_num_rows($sql_resultNum);
		?>
        <div class="comm_more">
        <?php if($Post['post_comments']=='true' and trim($OptionsLang["Comments_link"])!='') { ?>
            <a class="comments_num_link" href="<?php echo $thisPage; ?>?pid=<?php echo $Post['id']; ?>&amp;p=<?php if(isset($_REQUEST["p"])) echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;&search=<?php if(isset($_REQUEST["search"])) echo urlencode($_REQUEST["search"]); ?>#comments" title="<?php echo ReadHTML($Post["post_title"]); ?>">
            	<span class="comments_number"><?php echo $numComments; ?></span> 
				<span class="comments_numword"><?php echo $OptionsLang["Comments_link"]; ?></span>
            </a>
		<?php 
        }
        ?>
            
            <?php 			
            if(trim($Post["post_limit"])!='' and trim($OptionsLang["Read_more"])!="") {
            ?> 
            <a class="more_comm_num_link" href="<?php echo $thisPage; ?>?pid=<?php echo $Post['id']; ?>&amp;p=<?php if(isset($_REQUEST["p"])) echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php if(isset($_REQUEST["search"])) echo urlencode($_REQUEST["search"]); ?>#blt" title="<?php echo ReadHTML($Post["post_title"]); ?>"><?php echo $OptionsLang["Read_more"]; ?> <div class="arrow-right"></div> </a>  
             <?php } ?>           
        	<div class="clearboth"></div>
        </div>
        
       
        
        
    </div>
    
        
	<div class="dist_btw_posts"></div> 
    
    <?php 
	  }
	} else {
	?>     
    <?php echo $OptionsLang["No_Posts"]; ?>
    <?php 
	}
	
	$sql = "SELECT * FROM ".$TABLE["Posts"]." 
			WHERE status<>'Hidden' " .$search . "  
			ORDER BY publish_date DESC";
			
	$sql_resultOrig = sql_result($sql);	
	$numOfPostsOrig = mysqli_num_rows($sql_resultOrig);
	
	//echo "numOfPostsOrig=".$numOfPostsOrig."<br>";
	//echo "Options[per_page]=".$Options["per_page"]."<br>";
	
	if($numOfPostsOrig>$Options["per_page"]) {
	?>      
    <div class="loadbutton"><button class="loadmore" data-parameters="2-<?php if($_REQUEST["search"]!="") echo urlencode($_REQUEST["search"]); ?>-<?php echo $_REQUEST["cat_id"]; ?>"><?php echo $OptionsLang["LOAD_MORE"]; ?></button></div>
    <?php 
	}
	?>
    
	</div>
    
<?php
}
?>

<?php if($OptionsVis["show_scrolltop"]!="no") {?>
<a href="#myAnchor" class="cd-top">Top</a>
<script type="text/javascript">

//$('.front_end_wrapper').prepend('<a href="#0" class="cd-top">Top</a>');

jQuery(document).ready(function($){
	// browser window scroll (in pixels) after which the "back to top" link is shown
	var offset = 300,
	//browser window scroll (in pixels) after which the "back to top" link opacity is reduced
	offset_opacity = 1200,
	//duration of the top scrolling animation (in ms)
	scroll_top_duration = 700,
	//grab the "back to top" link
	$back_to_top = $('.cd-top');

	//hide or show the "back to top" link
	$(window).scroll(function(){
		( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
		if( $(this).scrollTop() > offset_opacity ) { 
			$back_to_top.addClass('cd-fade-out');
		}
	});

	//smooth scroll to top
	$back_to_top.on('click', function(event){
		event.preventDefault();
		$('body,html').animate({
			scrollTop: 0 ,
		 	}, scroll_top_duration
		);
	});

});

</script>
<?php } ?>
</div>
</div>
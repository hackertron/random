<?php 
$installed = '';
if(!isset($configs_are_set_blog)) {
	include( dirname(__FILE__). "/configs.php");
}

$thisPage = $_SERVER['PHP_SELF'];
if(!isset($_REQUEST["search"])) $_REQUEST["search"] = ''; 
if(!isset($_REQUEST["p"])) { 
	$_REQUEST["p"] = ''; 
} elseif(isset($_REQUEST["p"]) and $_REQUEST["p"]!="") {
	$_REQUEST["p"]= (int) urlencode($_REQUEST["p"]);
}

$search='';
if(isset($_REQUEST["search"]) and ($_REQUEST["search"]!="")) {
	$find = SafetyDB(urldecode($_REQUEST["search"]));
	$search .= " AND (post_title LIKE '%".$find."%' OR post_text LIKE '%".$find."%')";
} 

$sql = "SELECT * FROM ".$TABLE["Options"];
$sql_result = sql_result($sql);
$Options = mysqli_fetch_assoc($sql_result);
mysqli_free_result($sql_result);
$Options["comm_req"] = unserialize($Options["comm_req"]);
$OptionsVis = unserialize($Options['visual']);
$OptionsVisC = unserialize($Options['visual_comm']);
$OptionsLang = unserialize($Options['language']);


if(trim($Options['time_zone'])!='') {
	date_default_timezone_set(trim($Options['time_zone']));
}
$cur_date = date('Y-m-d H:i:s');

if(!function_exists('lang_date')){ 
	function lang_date($subject) {	
		$search  = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
		
		$replace = array(
						ReadDB($GLOBALS['OptionsLang']['January']), 
						ReadDB($GLOBALS['OptionsLang']['February']), 
						ReadDB($GLOBALS['OptionsLang']['March']), 
						ReadDB($GLOBALS['OptionsLang']['April']), 
						ReadDB($GLOBALS['OptionsLang']['May']), 
						ReadDB($GLOBALS['OptionsLang']['June']), 
						ReadDB($GLOBALS['OptionsLang']['July']), 
						ReadDB($GLOBALS['OptionsLang']['August']), 
						ReadDB($GLOBALS['OptionsLang']['September']), 
						ReadDB($GLOBALS['OptionsLang']['October']), 
						ReadDB($GLOBALS['OptionsLang']['November']), 
						ReadDB($GLOBALS['OptionsLang']['December']), 
						ReadDB($GLOBALS['OptionsLang']['Monday']), 
						ReadDB($GLOBALS['OptionsLang']['Tuesday']), 
						ReadDB($GLOBALS['OptionsLang']['Wednesday']), 
						ReadDB($GLOBALS['OptionsLang']['Thursday']), 
						ReadDB($GLOBALS['OptionsLang']['Friday']), 
						ReadDB($GLOBALS['OptionsLang']['Saturday']), 
						ReadDB($GLOBALS['OptionsLang']['Sunday'])
						);
	
		$lang_date = str_replace($search, $replace, $subject);
		return $lang_date;
	}
}

if(isset($_POST['parameters'])) {
	$ArrPost = explode("-", $_POST['parameters']);
 	$paged = $ArrPost[0];
	
	if(isset($ArrPost[1]) and ($ArrPost[1]!="")) {
		$find = SafetyDB(urldecode($ArrPost[1]));
		$search .= " AND (post_title LIKE '%".$find."%' OR post_text LIKE '%".$find."%')";
	} else {
		$ArrPost[1] = "";
	}
	
	if(isset($ArrPost[2]) and ($ArrPost[2]>0)) {
		$search .= " AND `cat_id`= ".SafetyDB(htmlentities($ArrPost[2]));
		$_REQUEST["cat_id"] = (int) SafetyDB(htmlentities($ArrPost[2]));
	} else {
		$ArrPost[2] = "";		
		$_REQUEST["cat_id"] = ''; 
	}
	
	$sql = "SELECT * FROM ".$TABLE["Posts"]." 
			WHERE status<>'Hidden' " .$search . "  
			ORDER BY publish_date DESC";
			
	$sql_resultOrig = sql_result($sql);	
	$numOfPostsOrig = mysqli_num_rows($sql_resultOrig);
	
	if($paged>0){
	   $page_limit=$Options["per_page"]*($paged-1);
	   $pagination_sql=" LIMIT  $page_limit, ".$Options["per_page"];
	}
	else{
		$pagination_sql=" LIMIT 0, ".$Options["per_page"];
	}
	
	//echo $sql.$pagination_sql."<br>";
	
	$sql_result = sql_result($sql.$pagination_sql);
	
	$numOfPosts = mysqli_num_rows($sql_result);
	
	if($numOfPosts>0){
		
	  while ($Post = mysqli_fetch_assoc($sql_result)) {
		//comments number
		$sqlC   = "SELECT count(*) as total FROM ".$TABLE["Comments"]." WHERE post_id='".$Post["id"]."' AND status='Approved'";
		$sql_resultC = sql_result($sqlC);
		$count = mysqli_fetch_array($sql_resultC);
		// fetch post category
		$sqlCat   = "SELECT * FROM ".$TABLE["Categories"]." WHERE `id`='".$Post["cat_id"]."'";
		$sql_resultCat = sql_result($sqlCat);
		$Cat = mysqli_fetch_array($sql_resultCat);
	?>
    
    <div class="post_list_wrapper" id="item_<?php echo $Post["id"]; ?>">
    	
        <!-- Post title -->
    	<div class="list_post_title"><a href="?pid=<?php echo $Post["id"]; ?>&amp;p=<?php if(isset($_REQUEST["p"])) echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php if(isset($_REQUEST["search"])) echo urlencode($_REQUEST["search"]); ?>#blt"><?php echo $Post["post_title"]; ?></a></div>    
    
        <div class="list_dist_title_date"></div>
        
        <!-- Post date -->   
        <?php if($OptionsVis["list_show_date"]!='no' or (isset($Cat["Cat"]) and $Cat["Cat"]>0)) { ?>  
        <div class="list_date_style">
        	<?php if($Cat["cat_name"]!="") echo $Cat["cat_name"]." / "; ?>
			<?php echo lang_date(date($OptionsVis["list_date_format"],strtotime($Post["publish_date"]))); ?> 
			<?php if($OptionsVis["list_showing_time"]!='') echo date($OptionsVis["list_showing_time"],strtotime($Post["publish_date"])); ?>
        </div>
        <?php } ?>
        
        <div class="list_dist_date_text"></div>
        
        <!-- Post text --> 
        <div class="list_post_text">
            <?php 			
			if(trim($Post["post_limit"])=='') {
				echo $Post["post_text"];
			} elseif(trim($Post["post_limit"])>0) {
				//$output = strip_only(cutStrHTML(ReadDB($Post["post_text"]), 0, $Post["post_limit"]), "div"); 
				if (isCyrillic($Post["post_text"])) {	
				  $output = truncateBlogHtml($Post["post_text"], $Post["post_limit"]);
				} else {
				  $output = TruncateHTML::truncateChars($Post["post_text"], $Post["post_limit"], '...');
				}
				echo $output;
			}
			?> 
      </div>
        
        
        
        <?php 
		$sqlNum = "SELECT * FROM ".$TABLE["Comments"]." WHERE post_id='".$Post["id"]."' AND status='Approved'";
		$sql_resultNum = sql_result($sqlNum);
		$numComments = mysqli_num_rows($sql_resultNum);
		?>
        <div class="comm_more">
        <?php if($Post['post_comments']=='true' and trim($OptionsLang["Comments_link"])!='') { ?>
            <a class="comments_num_link" href="?pid=<?php echo $Post['id']; ?>&amp;p=<?php if(isset($_REQUEST["p"])) echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php if(isset($_REQUEST["search"])) echo urlencode($_REQUEST["search"]); ?>#comments">
            	<span class="comments_number"><?php echo $numComments; ?></span> 
				<span class="comments_numword"><?php echo $OptionsLang["Comments_link"]; ?></span>
            </a>
		<?php 
        }
        ?>
            
            <?php 			
            if(trim($Post["post_limit"])!='') {
            ?> 
            <a class="more_comm_num_link" href="?pid=<?php echo $Post['id']; ?>&amp;p=<?php if(isset($_REQUEST["p"])) echo urlencode($_REQUEST['p']); ?>&amp;cat_id=<?php echo $_REQUEST["cat_id"]; ?>&amp;search=<?php if(isset($_REQUEST["search"])) echo urlencode($_REQUEST["search"]); ?>#blt"><?php echo $OptionsLang["Read_more"]; ?> <div class="arrow-right"></div> </a>  
             <?php } ?>           
        	<div class="clearboth"></div>
        </div>       
        
    </div>    
        
	<div class="dist_btw_posts"></div> 	
    
    <?php	
	  }
	}
	
	//echo "numOfPostsOrig=".$numOfPostsOrig."<br>";
	//echo "page_limit=".$page_limit."<br>";
	//echo "numOfPosts=".$numOfPosts."<br>";
	//echo "Options[per_page]=".$Options["per_page"]."<br>";
	
	if($numOfPosts==$Options["per_page"] and ($page_limit+$numOfPosts)<$numOfPostsOrig) {
	//if($numOfPosts==$Options["per_page"]) { ?>
 	<div class="loadbutton"><button class="loadmore" data-parameters="<?php echo $paged+1 ;?>-<?php echo $ArrPost[1]; ?>-<?php echo $ArrPost[2]; ?>"><?php echo $OptionsLang["LOAD_MORE"]; ?></button></div>
  <?php 
  } else {
  ?>
  	<div class='loadbutton'><h3><?php echo $OptionsLang["No_Posts"]; ?></h3></div>
  <?php 
  }
}
?>
<?php 
// here are stored database connection details, server path, script folder, URL to the script, and admin login details: //



?>
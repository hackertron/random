<?php session_start(); ?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php include("meta.php"); ?>
</head>

<body style="margin:0; padding:0;">

<?php include("blog.php"); ?>

<style type="text/css">
<!--
body {
	background-color: <?php echo $OptionsVis["gen_bgr_color"];?>;
}
-->
</style>


</body>
</html>
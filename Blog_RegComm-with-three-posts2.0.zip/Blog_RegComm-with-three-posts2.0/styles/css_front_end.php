<style type="text/css">

/* declare external fonts */
@font-face { font-family: Azbuka04; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/Azbuka04.ttf'); } 
@font-face { font-family: Cour; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/cour.ttf'); }  
@font-face { font-family: DSNote; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/(DS)_Note.ttf'); } 
@font-face { font-family: HebarU; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/HebarU.ttf'); } 
@font-face { font-family: Montserrat-Regular; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/Montserrat-Regular.otf'); }  
@font-face { font-family: MTCORSVA; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/MTCORSVA.TTF'); }  
@font-face { font-family: Nicoletta_script; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/Nicoletta_script.ttf'); } 
@font-face { font-family: Oswald-Regular; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/Oswald-Regular.ttf'); } 
@font-face { font-family: Raleway-Regular; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/Raleway-Regular.ttf'); }
@font-face { font-family: Regina Kursiv; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/ReginaKursiv.ttf'); }
@font-face { font-family: Ubuntu-R; src: url('<?php echo $CONFIG["full_url"]; ?>fonts/Ubuntu-R.ttf'); }  

/* div that wrap all the blog */
div.front_end_wrapper {
	font-family:<?php echo $OptionsVis["gen_font_family"];?>; 
	font-size:<?php echo $OptionsVis["gen_font_size"];?>;
	margin:0 auto !important;
	padding-top: <?php echo $OptionsVis["dist_from_top"];?> !important;
	padding-bottom: <?php echo $OptionsVis["dist_from_bottom"];?> !important; 
	color:<?php echo $OptionsVis["gen_font_color"];?>;
	text-align:<?php echo $OptionsVis["gen_text_align"];?>;
	line-height:<?php echo $OptionsVis["gen_line_height"];?>;
	word-wrap:break-word !important;
	<?php if(trim($OptionsVis["gen_width"])!=''){ ?>
	max-width: <?php echo trim($OptionsVis["gen_width"]); ?><?php echo $OptionsVis["gen_width_dim"]; ?> !important;
	<?php } ?>
}

/* search form style */
div.search_form_wrap {
	float:right;
}
div.search_form {
	text-align: right !important;
	width: 100%;
	/* border: solid 1px #6600FF; */	
}
div.search_form form {
	margin:0 !important; 
	padding:0 !important;
}
/* search input text field start */
.inputsearch[type=text] { 
	<?php if(isset($_REQUEST["search"]) and $_REQUEST["search"]!='') { ?>
	width: 100%;
	max-width: 280px;
	border-bottom: 1px solid <?php echo $OptionsVis["sear_bor_color"];?> !important;
	padding-bottom: 5px !important;
	<?php } else { ?>
	width: 0px;
	<?php } ?>
	box-sizing: border-box;
	border: 0;
	font-size: <?php echo $OptionsVis["sb_font_size"];?> !important;
	background-color: white;
	background-image: url('<?php echo $CONFIG["full_url"]; ?>images/searchicon.png');
	background-size: 18px 18px;
	background-position: right 10px center; 
	background-repeat: no-repeat;
	padding: 6px 36px 6px 6px;
	color: <?php echo $OptionsVis["sear_color"];?> !important;
}

.inputsearch[type=text]:focus {
	width: 100%;
	max-width: 280px;
	border-bottom: 1px solid <?php echo $OptionsVis["sear_bor_color"];?>;
	padding-bottom: 5px;
	background-size: 21px 21px;
}
@media screen and (max-width: 600px) {
	div.search_form_wrap {
		float: none;
		/* padding-top: <?php echo $OptionsVis["dist_search_title"];?> !important; */
		clear: both;
	}
	.inputsearch[type=text] { 
		<?php if(isset($_REQUEST["search"]) and $_REQUEST["search"]!='') { ?>
		width: 100%;
		max-width: 100%;
		<?php } else { ?>
		width: 0px;
		<?php } ?>
	}
	.inputsearch[type=text]:focus {
		width: 100%;
		max-width: 100%;
	}	
}
/* search input text field end */

/* clear float div recurring */
div.clearboth {
	clear:both !important;
	height:0 !important; 
	line-height:0 !important; 
	font-size:0 !important; 
	padding:0 !important; 
	margin:0 !important;
}

/* back link style */
div.back_link {
	padding-bottom:<?php echo $OptionsVis["dist_link_title"];?> !important;
}
div.back_link a {
	color:<?php echo $OptionsVis["back_font_color"];?> !important;
	font-size:<?php echo $OptionsVis["back_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["back_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["back_font_style"];?> !important; 
	text-decoration:<?php echo $OptionsVis["back_text_decoration"];?> !important;
}
/* "back link style on mouse over */
div.back_link a:hover {
	color:<?php echo $OptionsVis["back_font_color_hover"];?> !important;
	font-size:<?php echo $OptionsVis["back_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["back_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["back_font_style"];?> !important; 	
	text-decoration: <?php echo $OptionsVis["back_text_decoration_hover"];?> !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
.arrow-left {
	width: 0 !important; 
	height: 0 !important; 
	border-top: 4px solid transparent !important; 
	border-bottom: 4px solid transparent !important; 
	border-right: 4px solid <?php echo $OptionsVis["back_font_color"]; ?> !important; 
	display: inline-block !important; 
	margin-top: 1px !important; 
}
.arrow-left:hover {
	width: 0 !important; 
	height: 0 !important; 
	border-top: 4px solid transparent !important; 
	border-bottom: 4px solid transparent !important; 
	border-right: 4px solid <?php echo $OptionsVis["back_font_color_hover"]; ?> !important; 
	display: inline-block !important; 
	margin-top: 1px !important; 
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}

/* title on the full post style */
div.post_title {
	font-family:<?php echo $OptionsVis["post_title_font"];?> !important;
	color:<?php echo $OptionsVis["post_title_color"];?> !important;
	font-size:<?php echo $OptionsVis["post_title_size"];?> !important;
	font-weight:<?php echo $OptionsVis["post_title_font_weight"];?> !important;
	font-style: <?php echo $OptionsVis["post_title_font_style"];?> !important;
	text-align:<?php echo $OptionsVis["post_title_align"];?> !important;
	line-height: <?php echo $OptionsVis["title_line_height"];?> !important;
	text-decoration:none !important;
	border-bottom: solid <?php echo $OptionsVis["title_line_thick"];?> <?php echo $OptionsVis["title_line_color"];?> !important;
	padding-bottom: <?php echo $OptionsVis["title_dist_line"];?> !important;
}
/* title on the posts list style */
div.list_post_title {
	font-family:<?php echo $OptionsVis["list_title_font"];?> !important;
	color:<?php echo $OptionsVis["list_title_color"];?> !important;
	font-size:<?php echo $OptionsVis["list_title_size"];?> !important;
	font-weight:<?php echo $OptionsVis["list_title_font_weight"];?> !important;
	font-style: <?php echo $OptionsVis["list_title_font_style"];?> !important;
	text-align:<?php echo $OptionsVis["list_title_align"];?> !important;
	line-height: <?php echo $OptionsVis["list_title_line_height"];?> !important;
	text-decoration:none !important;
	border-bottom: solid <?php echo $OptionsVis["list_title_line_thick"];?> <?php echo $OptionsVis["list_title_line_color"];?> !important;
	padding-bottom: <?php echo $OptionsVis["list_title_dist_line"];?> !important;
}
div.list_post_title a {
	font-family:<?php echo $OptionsVis["list_title_font"];?> !important;
	color:<?php echo $OptionsVis["list_title_color"];?> !important;
	font-size:<?php echo $OptionsVis["list_title_size"];?> !important;
	font-weight:<?php echo $OptionsVis["list_title_font_weight"];?> !important;
	font-style: <?php echo $OptionsVis["list_title_font_style"];?> !important;
	text-align:<?php echo $OptionsVis["list_title_align"];?> !important;	
	text-decoration:none !important;
}
/* title on the posts list style on mouse over */
div.list_post_title a:hover {
	font-family:<?php echo $OptionsVis["list_title_font"];?> !important;
	color:<?php echo $OptionsVis["list_title_color_hover"];?> !important;
	font-size:<?php echo $OptionsVis["list_title_size"];?> !important;
	font-weight:<?php echo $OptionsVis["list_title_font_weight"];?> !important;
	font-style: <?php echo $OptionsVis["list_title_font_style"];?> !important;
	text-align:<?php echo $OptionsVis["list_title_align"];?> !important;
	text-decoration:none !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
/* post list title style end */

div.dist_title_date {
	clear:both !important; 
	height:<?php echo $OptionsVis["dist_title_date"];?> !important;
}
div.list_dist_title_date {
	clear:both !important; 
	height:<?php echo $OptionsVis["list_dist_title_date"];?> !important;
}
/* posts list date style */
div.list_date_style {
	font-family:<?php echo $OptionsVis["list_date_font"];?> !important; 
	color:<?php echo $OptionsVis["list_date_color"];?> !important; 
	font-size:<?php echo $OptionsVis["list_date_size"];?> !important; 
	font-style: <?php echo $OptionsVis["list_date_font_style"];?> !important; 
	text-align:<?php echo $OptionsVis["list_date_text_align"];?> !important; 
}
/* post date style */
div.date_style {
	color:<?php echo $OptionsVis["date_color"];?> !important; 
	font-family:<?php echo $OptionsVis["date_font"];?> !important; 
	font-size:<?php echo $OptionsVis["date_size"];?> !important; 
	font-style: <?php echo $OptionsVis["date_font_style"];?> !important; 
	text-align:<?php echo $OptionsVis["date_text_align"];?> !important; 
}
div.dist_date_text { 
	clear:both !important; 
	height:<?php echo $OptionsVis["dist_date_text"];?> !important;"
}
div.list_dist_date_text { 
	clear:both !important; 
	height:<?php echo $OptionsVis["list_dist_date_text"];?> !important;"
}

/* post text style */
div.post_text {
	font-family:<?php echo $OptionsVis["text_font"];?> !important;
	color:<?php echo $OptionsVis["text_color"];?> !important;
	background-color: <?php echo $OptionsVis["text_bgr_color"];?> !important;
	font-size:<?php echo $OptionsVis["text_size"];?>;
	font-weight:<?php echo $OptionsVis["text_font_weight"];?> !important;
	font-style: <?php echo $OptionsVis["text_font_style"];?> !important;
	text-align:<?php echo $OptionsVis["text_text_align"];?> !important;
	line-height:<?php echo $OptionsVis["text_line_height"];?> !important;
	padding: 0 <?php echo $OptionsVis["text_padding"];?> !important; 
	margin: 0 !important;	
}

/* post text images style */
div.post_text img {
	max-width: 100% !important;
	height: auto !important;
}

/* post text iframe style */
div.post_text iframe {
	max-width: 100% !important;
}

/* post text style */
div.list_post_text {
	font-family:<?php echo $OptionsVis["list_text_font"];?> !important;
	color:<?php echo $OptionsVis["list_text_color"];?> !important;
	background-color: <?php echo $OptionsVis["list_text_bgr_color"];?> !important;
	font-size:<?php echo $OptionsVis["list_text_size"];?>;
	font-weight:<?php echo $OptionsVis["list_text_font_weight"];?> !important;
	font-style: <?php echo $OptionsVis["list_text_font_style"];?> !important;
	text-align:<?php echo $OptionsVis["list_text_text_align"];?> !important;
	line-height:<?php echo $OptionsVis["list_text_line_height"];?> !important;
	padding: 0 <?php echo $OptionsVis["list_text_padding"];?> !important; 
	margin: 0 !important;	
}

/* post text images style */
div.list_post_text img {
	max-width: 100% !important;
	height: auto !important;
}

/* links style in the post text */
div.post_text a, div.list_post_text a {	
	color: <?php echo $OptionsVis["links_font_color"];?> !important;
	text-decoration: <?php echo $OptionsVis["links_text_decoration"];?> !important;
	font-size: <?php echo $OptionsVis["links_font_size"];?> !important;
	font-style: <?php echo $OptionsVis["links_font_style"];?> !important;
	font-weight: <?php echo $OptionsVis["links_font_weight"];?> !important;
}
/* links style in the post text on mouse over */
div.post_text a:hover {	
	color: <?php echo $OptionsVis["links_font_color_hover"];?> !important;
	text-decoration: <?php echo $OptionsVis["links_text_decoration_hover"];?> !important;
	font-size: <?php echo $OptionsVis["links_font_size"];?> !important;
	font-style: <?php echo $OptionsVis["links_font_style"];?> !important;
	font-weight: <?php echo $OptionsVis["links_font_weight"];?> !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}

/* share buttons style */
div.share_buttons {
	padding-top:6px !important; 
	float: <?php echo $Options["share_side"]; ?> !important;	
}

/* comment message style */
div.comment_message {
	padding:10px !important;
	color:red !important;
	font-weight:bold !important;	
}

/* style for word "Comments" above the list of comments */
div.word_Comments {
	padding-bottom:10px !important;
	font-family:<?php echo $OptionsVisC["w_comm_font_family"];?> !important;
	color:<?php echo $OptionsVisC["w_comm_font_color"];?> !important;
	font-size:<?php echo $OptionsVisC["w_comm_font_size"];?> !important;
	font-style:<?php echo $OptionsVisC["w_comm_font_style"];?> !important;
	font-weight:<?php echo $OptionsVisC["w_comm_font_weight"];?> !important;	
}

/* comment listing and comments form style */
.comments_wrapper {
	background-color:<?php echo $OptionsVisC["comm_bgr_color"];?> !important;
	padding:<?php echo $OptionsVisC["comm_padding"];?> <?php echo $OptionsVisC["comm_padd_dim"];?> !important;		
	<?php 
	if($OptionsVisC["comm_bord_sides"]=='all' or $OptionsVisC["comm_bord_sides"]=='top_bottom' or $OptionsVisC["comm_bord_sides"]=='top') {?>
	border-top:<?php echo $OptionsVisC["comm_bord_style"]." ".$OptionsVisC["comm_bord_width"]." ".$OptionsVisC["comm_bord_color"];?> !important;
	<?php } else { ?> 
	border-top: 0 !important;
	<?php } ?>
	
	<?php 
	if($OptionsVisC["comm_bord_sides"]=='all' or $OptionsVisC["comm_bord_sides"]=='top_bottom' or $OptionsVisC["comm_bord_sides"]=='bottom') {?>
	border-bottom:<?php echo $OptionsVisC["comm_bord_style"]." ".$OptionsVisC["comm_bord_width"]." ".$OptionsVisC["comm_bord_color"];?> !important;
	<?php } else { ?> 
	border-bottom: 0 !important;
	<?php } ?>
	
	<?php if($OptionsVisC["comm_bord_sides"]=='all' or $OptionsVisC["comm_bord_sides"]=='right_left' or $OptionsVisC["comm_bord_sides"]=='left'){?>
	border-left:<?php echo $OptionsVisC["comm_bord_style"]." ".$OptionsVisC["comm_bord_width"]." ".$OptionsVisC["comm_bord_color"];?> !important;
	<?php } else { ?> 
	border-left: 0 !important;
	<?php } ?>
	
	<?php if($OptionsVisC["comm_bord_sides"]=='all' or $OptionsVisC["comm_bord_sides"]=='right_left' or $OptionsVisC["comm_bord_sides"]=='right'){?>
	border-right:<?php echo $OptionsVisC["comm_bord_style"]." ".$OptionsVisC["comm_bord_width"]." ".$OptionsVisC["comm_bord_color"];?> !important;
	<?php } else { ?> 
	border-right: 0 !important;
	<?php } ?>
}
table.comments_wrapper {
	width: 100% !important;
}
table.comments_wrapper tr {
	background: none !important;
}
table.comments_wrapper td {
	padding: 8px 6px;
	margin:0 !important;
	border: 0 !important;
}
/* "Leave a Comment" style */
table.comments_wrapper td.leave_comment {
	color:<?php echo $OptionsVisC["leave_font_color"];?> !important; 
	font-size:<?php echo $OptionsVisC["leave_font_size"];?> !important; 
	font-weight:<?php echo $OptionsVisC["leave_font_weight"];?> !important; 
	font-style:<?php echo $OptionsVisC["leave_font_style"];?> !important;
}
/* comments form labels style */
table.comments_wrapper td.comment_labels {
	text-align: left !important;
	padding:6px;
	color:<?php echo $OptionsVisC["field_font_color"];?> !important; 
	font-size:<?php echo $OptionsVisC["field_font_size"];?> !important; 
	font-weight:<?php echo $OptionsVisC["field_font_weight"];?> !important; 
	font-style:<?php echo $OptionsVisC["field_font_style"];?> !important;
}
/* comments form fields style */
table.comments_wrapper td.comment_fields {
	text-align: left !important;
}
/* comments form label required field style */
table.comments_wrapper td.comment_required {
	padding-left:<?php echo $OptionsVisC["comm_padding"];?> !important;
	color:<?php echo $OptionsVisC["req_font_color"];?> !important;
	font-size:<?php echo $OptionsVisC["req_font_size"];?> !important;
	padding-top:0 !important;
	padding-bottom:0 !important;
}
/* comment form fields style */
.form_fields {
	color: #000000 !important;
	background-color: #FFFFFF !important;
	font-family: Helvetica !important;
	font-size: 16px !important;		
	font-weight: normal !important; 
	font-style: normal !important; 
	padding:1.5% !important;	
	border: solid 1px #dadada !important;
	border-radius: 0px !important;
	-webkit-border-radius: 0px !important;
	-moz-border-radius: 0px !important;
	margin: 0 !important;
	width: 96%;
}
.form_fields:focus, .searchinput:active {
	border: solid 1px #03A9F4 !important;
}
/* comment form fields placeholder style */
.form_fields::-webkit-input-placeholder {
   color: #767676;
}
.form_fields:-moz-placeholder { /* Firefox 18- */
   color: #767676;  
}
.form_fields::-moz-placeholder {  /* Firefox 19+ */
   color: #767676;  
}
.form_fields:-ms-input-placeholder {  
   color: #767676;  
}

.form_textarea {
	font-size: 14px !important;		
	font-weight: normal !important; 
	font-style: normal !important; 
	width:95% !important;
	display:block !important; 
	float:left !important;
}
.form_field_95 {
	width:95% !important;
	display:block !important; 
	float:left !important;
}
.form_field_100 {
	width:100% !important;
}

.form_field_96 {
	width:96% !important;
}

td.comment_button {
	padding-top: 30px !important;
}


/* Submit button*/
.submitbtn {	
	color:<?php echo $OptionsVisC["subm_color"];?> !important;
	font-size:14px !important;
	font-weight:<?php echo $OptionsVisC["subm_font_weight"];?> !important;
	font-style:<?php echo $OptionsVisC["subm_font_style"];?> !important;	
	border:1px solid <?php echo $OptionsVisC["subm_brdr_color"];?> !important;
	background-color: <?php echo $OptionsVisC["subm_bgr_color"];?> !important;
	border-radius:<?php echo $OptionsVisC["subm_bor_radius"];?> !important;
	-webkit-border-radius:<?php echo $OptionsVisC["subm_bor_radius"];?> !important;
	-moz-border-radius:<?php echo $OptionsVisC["subm_bor_radius"];?> !important;
	-khtml-border-radius: <?php echo $OptionsVisC["subm_bor_radius"];?> !important;
	text-indent:0 !important;
	background-image: none !important;
	cursor: pointer !important;
	display:inline-block !important;
	text-decoration:none !important;
	text-shadow: none !important;
	text-align:center !important;
	padding: 10px 38px;
	-webkit-transition: border-color .3s ease-out,color .3s ease-out,background-color .3s ease-out; /* Safari */
	transition: border-color .3s ease-out,color .3s ease-out,background-color .3s ease-out;
	letter-spacing: 1px;
}
.submitbtn:hover {
	color: <?php echo $OptionsVisC["subm_brdr_color"];?> !important;
	background-color:<?php echo $OptionsVisC["subm_bgr_color_on"];?> !important;
	-webkit-transition: border-color .3s ease-out,color .3s ease-out,background-color .3s ease-out; /* Safari */
	transition: border-color .3s ease-out,color .3s ease-out,background-color .3s ease-out;
}


/* post listing wrapper in the list of posts page */
div.post_list_wrapper {
	background-color:<?php echo $OptionsVis["post_bgr_color"];?> !important;
	padding:<?php echo $OptionsVis["posts_padding"];?> !important; 
	
	<?php if($OptionsVis["Border_sides"]=='all' or $OptionsVis["Border_sides"]=='top_bottom' or $OptionsVis["Border_sides"]=='top') {?>
	border-top:<?php echo $OptionsVis["Border_style"]." ".$OptionsVis["Border_width"]." ".$OptionsVis["Border_color"];?> !important;
	<?php } ?> 
	
	<?php if($OptionsVis["Border_sides"]=='all' or $OptionsVis["Border_sides"]=='top_bottom' or $OptionsVis["Border_sides"]=='bottom') {?>
	border-bottom:<?php echo $OptionsVis["Border_style"]." ".$OptionsVis["Border_width"]." ".$OptionsVis["Border_color"];?> !important;
	<?php } ?> 
	
	<?php if($OptionsVis["Border_sides"]=='all' or $OptionsVis["Border_sides"]=='right_left' or $OptionsVis["Border_sides"]=='left') {?>
	border-left:<?php echo $OptionsVis["Border_style"]." ".$OptionsVis["Border_width"]." ".$OptionsVis["Border_color"];?> !important;
	<?php } ?> 
	
	<?php if($OptionsVis["Border_sides"]=='all' or $OptionsVis["Border_sides"]=='right_left' or $OptionsVis["Border_sides"]=='right') {?>
	border-right:<?php echo $OptionsVis["Border_style"]." ".$OptionsVis["Border_width"]." ".$OptionsVis["Border_color"];?> !important;
	<?php } ?>	
}

/* Distances in "COMMENTS" and "MORE" links underneath the posts in the list */
.comm_more {
	padding: <?php echo $OptionsVis["dist_btw_post_more"];?> 0 <?php echo $OptionsVis["dist_btw_more_line"];?> 0 !important;
	clear:both;
}
/* "COMMENTS" link */
a.comments_num_link {
	color:<?php echo $OptionsVis["coml_font_color"];?> !important;
	font-family:<?php echo $OptionsVis["coml_font"];?> !important;
	font-size:<?php echo $OptionsVis["coml_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["coml_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["coml_font_style"];?> !important;
	text-decoration:<?php echo $OptionsVis["coml_text_decoration"];?> !important;
	display:block !important;
	float: left !important;
}
/* Comments(number) on mouse over */
a.comments_num_link:hover {
	color:<?php echo $OptionsVis["coml_font_color_hover"];?> !important;
	font-family:<?php echo $OptionsVis["coml_font"];?> !important;
	font-size:<?php echo $OptionsVis["coml_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["coml_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["coml_font_style"];?> !important;
	text-decoration:<?php echo $OptionsVis["coml_text_decoration_hover"];?> !important;
	display:block !important;
	float: left !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
.comments_number {
	padding: 0 1px 0 0 !important;
}
.comments_numword {
	color: <?php echo $OptionsVis["coml_font_color"];?> !important; 	
}

/* "MORE" link */
a.more_comm_num_link {
	color:<?php echo $OptionsVis["more_font_color"];?> !important;
	font-family:<?php echo $OptionsVis["more_font"];?> !important;
	font-size:<?php echo $OptionsVis["more_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["more_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["more_font_style"];?> !important;
	text-decoration:<?php echo $OptionsVis["more_text_decoration"];?> !important;
	display:block !important;
	float: right !important;
}
/* "MORE" link */
a.more_comm_num_link:hover {
	color:<?php echo $OptionsVis["more_font_color_hover"];?> !important;
	font-family:<?php echo $OptionsVis["more_font"];?> !important;
	font-size:<?php echo $OptionsVis["more_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["more_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["more_font_style"];?> !important;
	text-decoration:<?php echo $OptionsVis["more_text_decoration_hover"];?> !important;
	display:block !important;
	float: right !important;	
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
.arrow-right {
	width: 0 !important; 
	height: 0 !important; 
	border-top: 4px solid transparent !important; 
	border-bottom: 4px solid transparent !important; 
	border-left: 4px solid <?php echo $OptionsVis["more_font_color"]; ?> !important; 
	display: inline-block !important; 
	margin-top: 2px !important; 
}
.arrow-right:hover {
	width: 0 !important; 
	height: 0 !important; 
	border-top: 4px solid transparent !important; 
	border-bottom: 4px solid transparent !important; 
	border-left: 4px solid <?php echo $OptionsVis["more_font_color_hover"]; ?> !important; 
	display: inline-block !important; 
	margin-top: 2px !important; 	
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}

/* Distance between posts in the list */
div.dist_btw_posts { 
	clear:both !important; 
	height:<?php echo $OptionsVis["dist_btw_posts"];?> !important;
}

/* navigation at the bottom style */
table.bottom_navigator {
	width:100% !important;
	border:0 !important;
	border-collapse: collapse !important; 
	border-spacing: 0 !important;
}	
table.bottom_navigator td {
	padding: <?php echo $OptionsVis["dist_comm_links"];?> 16px 0 16px !important;
	width: 33% !important;
	border: 0 !important;
}
table.bottom_navigator td.older_post {
	text-align: left !important;
}
table.bottom_navigator td.home_post {
	text-align: center !important;
}
table.bottom_navigator td.newer_post {
	text-align: right !important;
}
/*  navigation at the bottom "Older Post", "Home", "Newer Post" links style */
a.nav_active {
	color:<?php echo $OptionsVis["bott_color"];?> !important;
	font-size:<?php echo $OptionsVis["bott_size"];?> !important;
	font-style:<?php echo $OptionsVis["bott_style"];?> !important; 
	font-weight:<?php echo $OptionsVis["bott_weight"];?> !important;
	text-decoration:<?php echo $OptionsVis["bott_decoration"];?> !important;
}
/*  navigation at the bottom "Older Post", "Home", "Newer Post" links on hover */
a.nav_active:hover {
	color:<?php echo $OptionsVis["bott_color_hover"];?> !important;
	font-size:<?php echo $OptionsVis["bott_size"];?> !important;
	font-style:<?php echo $OptionsVis["bott_style"];?> !important; 	
	font-weight:<?php echo $OptionsVis["bott_weight"];?> !important;
	text-decoration: <?php echo $OptionsVis["bott_decoration_hover"];?> !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
/*  navigation at the bottom "Older Post", "Home", "Newer Post" links inactive */
.nav_inactive {
	color:<?php echo $OptionsVis["bott_color_inact"];?> !important;
	font-size:<?php echo $OptionsVis["bott_size"];?> !important;
	font-style:<?php echo $OptionsVis["bott_style"];?> !important; 	
	font-weight:<?php echo $OptionsVis["bott_weight"];?> !important;
	text-decoration: none;
}


/* captcha image fields styles start */
.form_captcha {
	color: #000000 !important;
	background-color: #FFF !important; 
	font-family: Helvetica !important;
	font-size: 16px !important;		
	font-weight: normal !important; 
	font-style: normal !important; 	
	padding:5px;	
	border: solid 1px #dadada !important;
	border-radius: 0px !important;
	-webkit-border-radius: 0px !important;
	-moz-border-radius: 0px !important;
	margin: 0 !important;
}
.form_captcha:focus, .form_captcha:active {
	border: solid 1px #03A9F4 !important;
}
	.form_captcha_img {
		display:block;
		float:left;
	}
	.form_captcha_eq {	
		float:left;
		padding-top:9px;
		padding-left:3px;
		padding-right:3px;
		font-size:20px;
		color:#666;
		font-weight:bold;
	}
	.form_captcha_math {		
		width:40px;
		display:block;
		float:left;
		margin-top:4px;
		height:28px;
		font-size:17px; 
		text-align:center;
	}
	.form_captcha_s {
		width:66px;
		height:23px;
		display:block;
		float:left;
		margin-left:10px !important;
	}
	.form_asterisk {
		float:left;
		padding-left:5px;
		padding-top:10px;
	}
/* make google reCaptcha responsive width */	
@media (min-width: 320px) and (max-width: 480px) {
	#recaptcha_challenge_image {
		margin: 0 !important;
		width: 100% !important;
	}
	#recaptcha_response_field
	{
	margin: 0 !important;
	width: 100% !important;
	}
	.recaptchatable #recaptcha_image {
	margin: 0 !important;
	width: 100% !important;
	}
	.recaptchatable .recaptcha_r1_c1, 
	.recaptchatable .recaptcha_r3_c1, 
	.recaptchatable .recaptcha_r3_c2, 
	.recaptchatable .recaptcha_r7_c1, 
	.recaptchatable .recaptcha_r8_c1, 
	.recaptchatable .recaptcha_r3_c3, 
	.recaptchatable .recaptcha_r2_c1, 
	.recaptchatable .recaptcha_r4_c1, 
	.recaptchatable .recaptcha_r4_c2, 
	.recaptchatable .recaptcha_r4_c4, 
	.recaptchatable .recaptcha_image_cell {

	margin: 0 !important;
	width: 100% !important;
	background: none !important;
	}

}
/* captcha image fields styles ends */	

.loadmore {
	color: <?php echo $OptionsVis["pag_font_color"];?> !important;	
	border: solid 1px <?php echo $OptionsVis["pag_bord_color"];?> !important;
	-webkit-border-radius: <?php echo $OptionsVis["pag_bor_radius"];?> !important;
	-moz-border-radius: <?php echo $OptionsVis["pag_bor_radius"];?> !important;
	border-radius: <?php echo $OptionsVis["pag_bor_radius"];?> !important;
	background-color: <?php echo $OptionsVis["pag_bgr_color"];?> !important;
	font-family: <?php echo $OptionsVis["pag_font_family"]; ?> !important;
	font-size: <?php echo $OptionsVis["pag_font_size"];?> !important;
	font-style: <?php echo $OptionsVis["pag_font_style"];?> !important;
	font-weight: <?php echo $OptionsVis["pag_font_weight"]; ?> !important;
	width: <?php echo $OptionsVis["loadmore_width"]; ?><?php echo $OptionsVis["loadmore_dim"]; ?>;
	padding: <?php echo $OptionsVis["loadmore_padd"]; ?>;
	outline: 0;
	cursor: pointer;
}
.loadmore:hover {
	color: <?php echo $OptionsVis["pag_font_color_hover"];?> !important;
	border: 1px solid <?php echo $OptionsVis["pag_bord_color_hover"];?> !important;
	background-color: <?php echo $OptionsVis["pag_bgr_color_hover"];?> !important;
}
 .loadbutton{
	text-align: <?php echo $OptionsVis["pag_align_to"];?> !important;
}

/* scroll to top styles */
.cd-top {
	display: inline-block;
	width: <?php echo $OptionsVis["scrolltop_width"];?>;
	height: <?php echo $OptionsVis["scrolltop_height"];?>;
	position: fixed;
	bottom: 40px;
	right: 10px;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
	/* image replacement properties */
	overflow: hidden;
	text-indent: 100%;
	white-space: nowrap;
	background: <?php echo $OptionsVis["scrolltop_bgr_color"];?> url(<?php echo $CONFIG["full_url"]; ?>images/cd-top-arrow.svg) no-repeat center 50%;
	visibility: hidden;
	opacity: 0;
	-webkit-transition: opacity .3s 0s, visibility 0s .3s;
	-moz-transition: opacity .3s 0s, visibility 0s .3s;
	transition: opacity .3s 0s, visibility 0s .3s;
	z-index: 9999;
	-webkit-border-radius: <?php echo $OptionsVis["scrolltop_radius"];?> !important;
	-moz-border-radius: <?php echo $OptionsVis["scrolltop_radius"];?> !important;
	border-radius: <?php echo $OptionsVis["scrolltop_radius"];?> !important;
}
.cd-top.cd-is-visible, .cd-top.cd-fade-out, .cd-top:hover {
	-webkit-transition: opacity .3s 0s, visibility 0s 0s;
	-moz-transition: opacity .3s 0s, visibility 0s 0s;
	transition: opacity .3s 0s, visibility 0s 0s;
}
.cd-top:hover {
	background-color: <?php echo $OptionsVis["scrolltop_bgr_color_hover"];?>;
}
.cd-top.cd-is-visible {
	/* the button becomes visible */
	visibility: visible;
	-khtml-opacity:<?php echo $OptionsVis["scrolltop_opacity"]/100;?>; 
	-moz-opacity:<?php echo $OptionsVis["scrolltop_opacity"]/100;?>; 
	filter: progid:DXImageTransform.Microsoft.Alpha(opacity=<?php echo $OptionsVis["scrolltop_opacity"]/100;?>);
	opacity: <?php echo $OptionsVis["scrolltop_opacity"]/100;?>; 
	filter:alpha(opacity=<?php echo $OptionsVis["scrolltop_opacity"];?>);
}
.cd-top.cd-fade-out {
	/* if the user keeps scrolling down, the button is out of focus and becomes less visible */
	-khtml-opacity:<?php echo $OptionsVis["scrolltop_opacity_hover"]/100;?>; 
	-moz-opacity:<?php echo $OptionsVis["scrolltop_opacity_hover"]/100;?>; 
	filter: progid:DXImageTransform.Microsoft.Alpha(opacity=<?php echo $OptionsVis["scrolltop_opacity_hover"]/100;?>);
	opacity: <?php echo $OptionsVis["scrolltop_opacity_hover"]/100;?>; 
	filter:alpha(opacity=<?php echo $OptionsVis["scrolltop_opacity_hover"];?>);
}
@media only screen and (min-width: 768px) {
  .cd-top {
    right: 20px;
    bottom: 20px;
  }
}
@media only screen and (min-width: 1024px) {
  .cd-top {
    width: <?php echo $OptionsVis["scrolltop_width"];?>;
  	height: <?php echo $OptionsVis["scrolltop_height"];?>;
    right: 30px;
    bottom: 30px;
  }
}

/* scroll to top style end */

/* drop down menu for categories */
.dropdown {
    position: relative;
    display: inline-block;
	float:left;
	/* border: solid 1px #FF0000; */
}

.dropbtn {
    color: <?php echo $OptionsVis["cat_word_color"];?>;
	font-family: <?php echo $OptionsVis["cat_word_family"];?>;
    font-size: <?php echo $OptionsVis["cat_word_font_size"];?>;
	font-style: <?php echo $OptionsVis["cat_word_font_style"];?>;
	font-weight: <?php echo $OptionsVis["cat_word_font_weight"];?>;
    background-color: <?php echo $OptionsVis["cat_word_bgcolor"];?>;
    padding: 4px 2px;
    border: none;
    cursor: pointer;
}

.dropdown-content {
    background-color: <?php echo $OptionsVis["cat_dd_bgr_color"];?>;
    display: none;
    position: absolute;
    min-width: 100%;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
	white-space: nowrap;
}

.dropdown-content a {
    color: <?php echo $OptionsVis["cat_dd_color"];?>;
	font-family: <?php echo $OptionsVis["cat_dd_family"];?>;
	font-size: <?php echo $OptionsVis["cat_dd_font_size"];?>;
	font-style: <?php echo $OptionsVis["cat_dd_font_style"];?>;
	font-weight: <?php echo $OptionsVis["cat_dd_font_weight"];?>;
	text-align: <?php echo $OptionsVis["cat_dd_align"];?>;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {
	background-color: <?php echo $OptionsVis["cat_dd_bgr_color_hover"];?>;
}

.dropdown2:hover .dropdown-content {
    display: block;
}
@media only screen and (max-width: 600px) {
	.dropdown {
		display:inline;
		float: none;
	}
	.dropbtn {
		width: 99%;
		margin-top: <?php echo $OptionsVis["dist_search_title"];?> !important;
	}
}

/* clear float div recurring */
div.dist_search_title {
	clear:both !important;
	height:0 !important; 
	line-height:0 !important; 
	font-size:0 !important; 
	padding:0; 
	margin:0 !important;
	padding-bottom: <?php echo $OptionsVis["dist_search_title"];?> !important;
}


blockquote {
  background: #f9f9f9;
  border-left: 10px solid #ccc;
  margin: 1.5em 10px;
  padding: 0.5em 10px;
  quotes: "\201C""\201D""\2018""\2019";
}
blockquote:before {
  color: #ccc;
  content: open-quote;
  font-size: 4em;
  line-height: 0.1em;
  margin-right: 0.25em;
  vertical-align: -0.4em;
}
blockquote p {
  display: inline;
}


a.reg_link {
	color:<?php echo $OptionsVis["back_font_color"];?> !important;
	font-size:<?php echo $OptionsVis["back_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["back_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["back_font_style"];?> !important; 
	text-decoration:<?php echo $OptionsVis["back_text_decoration"];?> !important;
}
/* "back link style on mouse over */
a.reg_link:hover {
	color:<?php echo $OptionsVis["back_font_color_hover"];?> !important;
	font-size:<?php echo $OptionsVis["back_font_size"];?> !important;
	font-weight:<?php echo $OptionsVis["back_font_weight"];?> !important;
	font-style:<?php echo $OptionsVis["back_font_style"];?> !important; 	
	text-decoration: <?php echo $OptionsVis["back_text_decoration_hover"];?> !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}

@media (max-width: 600px) {
	.form_textarea{
		 width:96%;
		 padding: 5px;
		 margin-top: 10px;
		 border:1px solid #7ac9b7;
		 margin-bottom: 20px;
		 resize:none;
	 }
}


.form_field_50 {
	width:50%;
}
.form_field_60 {
	width:60% !important;
}
@media screen and (max-width: 680px) {
	.form_field_60 {
		width:94% !important;
	}
	.form_field_50 {
		width:94%;
	}
}

.form_field_55 {
	width:55%;
}
.form_field_95 {
	width:95%;
}

.avatar_img {
	width: <?php echo $OptionsVisC["avat_width"]; ?>px;
	border: 0 !important;
}
.avat_no_img {
	width: <?php echo $OptionsVisC["avat_width"]; ?>;
	border: 0 !important;
}

/* --------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------- */
/* ------- css style for the Latest 3 Posts underneath the actual post text -------- */
.Latest3posts {
	font-family:<?php echo $OptionsVis["w_lat_p_font"]; ?> !important;
 	color:<?php echo $OptionsVis["w_lat_p_color"]; ?> !important;
 	font-size:<?php echo $OptionsVis["w_lat_p_size"]; ?> !important;
 	font-weight:<?php echo $OptionsVis["w_lat_p_font_weight"]; ?> !important;
 	font-style: <?php echo $OptionsVis["w_lat_p_font_style"]; ?> !important;
	padding: 24px 0 10px 0;	
}
.dbl-third-padd-float {
	float:left;
 	width: 30.32%;
	padding: 1.5%;
}
@media only screen and (max-width:600px) {
	.dbl-third-padd-float {
		float:left;
		width: 100%;
		padding: 1.5%;
	}
}
.dbl-box-shadow {
	box-shadow: 0 4px 10px 0 rgba(160, 160, 160, 0.2), 0 4px 10px 0 rgba(160, 160, 160, 0.19);
}
.dbl-title-descr-grid {
	padding: 4.4%;
 	background-color: inherit;
	text-align:<?php echo $OptionsVis["lat_post_title_align"]; ?> !important;
}
/* style for the blog titles in the latest posts start */
.dbl-title-grid {
 	font-family:<?php echo $OptionsVis["lat_post_title_font"]; ?> !important;
 	color:<?php echo $OptionsVis["lat_post_title_color"]; ?> !important;
 	font-size:<?php echo $OptionsVis["lat_post_title_size"]; ?> !important;
 	font-weight:<?php echo $OptionsVis["lat_post_title_font_weight"]; ?> !important;
 	font-style: <?php echo $OptionsVis["lat_post_title_font_style"]; ?> !important;
 	text-align:<?php echo $OptionsVis["lat_post_title_align"]; ?> !important;
 	line-height: <?php echo $OptionsVis["lat_title_line_height"]; ?> !important;
	text-decoration:none !important;
	-webkit-transition: color .1s ease-out;
	transition: color .1s ease-out;
}
.dbl-title-grid:hover {
 	font-family:<?php echo $OptionsVis["lat_post_title_font"]; ?> !important;
 	color:<?php echo $OptionsVis["lat_post_title_color_hover"]; ?> !important;
 	font-size:<?php echo $OptionsVis["lat_post_title_size"]; ?> !important;
 	font-weight:<?php echo $OptionsVis["lat_post_title_font_weight"]; ?> !important;
 	font-style: <?php echo $OptionsVis["lat_post_title_font_style"]; ?> !important;
 	text-align:<?php echo $OptionsVis["lat_post_title_align"]; ?> !important;
	text-decoration:none !important;
	-webkit-transition: color .2s ease-out;
	transition: color .2s ease-out;
}
/* style for the blog titles in the latest posts end */

/* distance in the latest posts title-date */
div.dbl-grid-dist-title-date {
	clear:both !important;
 	height: 20px !important;
}
/* date style in the latest posts */
div.dbl-grid-date-style {
 	font-family:<?php echo $OptionsVis["list_date_font"]; ?> !important;
 	color:<?php echo $OptionsVis["list_date_color"]; ?> !important;
 	font-size:<?php echo $OptionsVis["list_date_size"]; ?> !important;
 	font-style: <?php echo $OptionsVis["list_date_font_style"]; ?> !important;
 	text-align:<?php echo $OptionsVis["list_date_text_align"]; ?> !important;
	float: left;
}
/* "COMMENTS" link in the latest posts */
a.dbl-comments-num-link {
 	color:<?php echo $OptionsVis["coml_font_color"]; ?> !important;
 	font-family:<?php echo $OptionsVis["coml_font"]; ?> !important;
 	font-size:<?php echo $OptionsVis["coml_font_size"]; ?> !important;
 	font-weight:<?php echo $OptionsVis["coml_font_weight"]; ?> !important;
 	font-style:<?php echo $OptionsVis["coml_font_style"]; ?> !important;
	text-decoration: none !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
	display: block;
	float: right;
}
/* Comments(number) on mouse over in the latest posts */
a.dbl-comments-num-link:hover {
 	color:<?php echo $OptionsVis["coml_font_color_hover"]; ?> !important;
 	font-family:<?php echo $OptionsVis["coml_font"]; ?> !important;
 	font-size:<?php echo $OptionsVis["coml_font_size"]; ?> !important;
 	font-weight:<?php echo $OptionsVis["coml_font_weight"]; ?> !important;
 	font-style:<?php echo $OptionsVis["coml_font_style"]; ?> !important;
	text-decoration: none !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
/* "COMMENTS" icon in the latest posts */
.dbl-comments-num-link i {
 	color:<?php echo $OptionsVis["coml_font_color"]; ?> !important;
	font-size:<?php echo $OptionsVis["list_date_size"]; ?> !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
/* Comments(number) on mouse over in the latest posts */
.dbl-comments-num-link i:hover {
 	color:<?php echo $OptionsVis["coml_font_color_hover"]; ?> !important;
 	font-size:<?php echo $OptionsVis["coml_font_size"]; ?> !important;
	-webkit-transition: color .3s ease-out;
	transition: color .3s ease-out;
}
div.dbl-grid-dist-date-text {
	clear:both !important;
	height:<?php echo $OptionsVis["list_dist_date_text"]; ?> !important;
	line-height: 0px !important;
}
.dbl-image-wrapper-grid {
	display:block;
	overflow:hidden;
}
.dbl-image-grid {
	position: relative;
	width: 100%;
 	<?php 
		$ratio = 75;
	?>  
	padding-bottom : 56%; /* = width for a 1:1 aspect ratio */
	background-position:center center;
	background-repeat:no-repeat;
	background-size:cover; /* you change this to "contain" if you don't want the images to be cropped */
	transition: all .15s ease-in-out;
}
.dbl-image-grid:hover {
	opacity: 0.7;
	transition: all .15s ease-in-out;
	transform: scale(1.1);
	-moz-transform: scale(1.1);
	-webkit-transform: scale(1.1);
	-o-transform: scale(1.1);
	-ms-transform: scale(1.1); /* IE 9 */
	-ms-filter: "progid:DXImageTransform.Microsoft.Matrix(M11=1.5, M12=0, M21=0, M22=1.5, SizingMethod='auto expand')"; /* IE8 */
 	filter: progid:DXImageTransform.Microsoft.Matrix(M11=1.5, M12=0, M21=0, M22=1.5, SizingMethod='auto expand'); /* IE6 and 7 */
}
</style>